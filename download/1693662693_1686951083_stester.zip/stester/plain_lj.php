<?php
class plugin {

	private $sphinxql = false;

	public function init() {
		$options = getopt('', array('port::', 'index::', 'maxmatches::', 'filter::'));

		$port = isset($options['port']) ? $options['port'] : 9314;
		$this->idx = isset($options['index']) ? $options['index'] : 'lj';
		if (isset($options['maxmatches'])) $this->maxmatches = " limit ".$options['maxmatches']." option max_matches=".$options['maxmatches'];
		else $this->maxmatches = " limit 10 option max_matches=1000";

		$this->filter = '';
		if (isset($options['filter']))
			$this->filter = " AND ".$options['filter']." ";

		$this->sphinxql = new mysqli('127.0.0.1', '', '', '', $port);

	}

	public function query($queries) {
		$out = array();
		foreach ($queries as $id=>$query) {
			if (!$query) continue;
			$t = microtime(true);
			$res = $this->sphinxql->query("select * from ".$this->idx." where match('@(title,content) (".$this->sphinxql->escape_string($query).")')" . $this->filter . $this->maxmatches);
			$out[$id] = array('latency' => microtime(true) - $t, 'num_rows' => 0);
			$res = $this->sphinxql->query("show meta");
			while ($row = $res->fetch_array()) {
				if ($row[0] == 'total_found') {
					$out[$id]['num_rows'] = $row[1];
					break;
				}
			}
			/*$ids = array();
			while($row = $res->fetch_array()) $ids[] = $row['id'];
			sort($ids);
			if ($ids) file_put_contents('/tmp/compare/ms_'.$id, implode("\n", $ids));*/
		}
		return $out;
	}

	public static function report($queriesInfo) {
		$totalMatches = 0;
		foreach($queriesInfo as $id => $info) {
			$totalMatches += $info['num_rows'];
		}
		return array(
		'Total matches' => $totalMatches,
		'Count' => count($queriesInfo));
	}
}
