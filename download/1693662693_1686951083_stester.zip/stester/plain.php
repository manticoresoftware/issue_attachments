<?php
class plugin {

	private $sphinxql = false;

	public function init() {
		$options = getopt('', array('port:', 'host::'));

		$port = isset($options['port']) ? $options['port'] : 9315;
                $host = isset($options['host']) ? $options['host'] : '127.0.0.1';
		$this->sphinxql = new mysqli($host, '', '', '', $port);

	}

	public function query($queries) {
		$out = array();
		foreach ($queries as $id=>$query) {
			$t = microtime(true);
			#$res = $this->sphinxql->query($this->sphinxql->escape_string($query));
            $res = $this->sphinxql->query($query);
			$out[$id] = array('latency' => microtime(true) - $t, 'num_rows' => isset($res->num_rows) ? $res->num_rows : 0);
		}
		return $out;
	}

	public static function report($queriesInfo) {
		$totalMatches = 0;
		foreach($queriesInfo as $id => $info) {
			$totalMatches += $info['num_rows'];
		}
		return array(
		'Total matches' => $totalMatches,
		'Count' => count($queriesInfo));
	}
}
