<?php
class plugin {

	private $sphinxql = false;

	public function init() {
                $options = getopt('', array('ip::'));
		$this->sphinxql = new mysqli($options['ip'], '', '', '', 9306);
	}

	public function query($queries) {
		$out = array();
		foreach ($queries as $id=>$query) {
			$t = microtime(true);
			$res = $this->sphinxql->query('SELECT id,group_id,IF((IN(sell_status,2,3,4,7) AND price > 0), 2, IF (IN(sell_status,5),0,1)) as atp_order,rank_order as order_field FROM section_4,section_9 WHERE status=1 AND status_inherited=1 AND sell_status IN (0,1,2,3,4,7) GROUP BY grouping WITHIN GROUP ORDER BY group_rank DESC, id DESC ORDER BY atp_order DESC,order_field ASC LIMIT 0,16 OPTION max_matches=100000, max_query_time=1500');
			$out[$id] = array('latency' => microtime(true) - $t, 'num_rows' => isset($res->num_rows) ? $res->num_rows : 0);
		}
		return $out;
	}

	public static function report($queriesInfo) {
		$totalMatches = 0;
		foreach($queriesInfo as $id => $info) {
			$totalMatches += $info['num_rows'];
		}
		return array(
		'Total matches' => $totalMatches,
		'Count' => count($queriesInfo));
	}
}
