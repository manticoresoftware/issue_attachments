<?php
class plugin {

	private $sphinxql = false;

	public function init() {
		$this->sphinxql = new mysqli('127.0.0.1', '', '', '', 9315);
		$this->sphinxql->query("truncate rtindex table");
                $this->sphinxql->query("truncate rtindex table2");
//		unlink('/tmp/query_log.txt');
	}

	public function query($queries) {
		$out = array();
		foreach ($queries as $id=>$query) {
			if (!is_array($query) or count($query) != 11) continue;
			$t = microtime(true);
			$tables = array('table', 'table2');
			$query = "insert into ".$tables[rand(0,1)]."(id, story_id, story_time, story_text, story_author, comment_id, comment_text, comment_author, comment_ranking, author_comment_count, story_comment_count) values(".crc32(rand()).",{$query[0]},{$query[1]},'".$this->sphinxql->escape_string($query[3])."','".$this->sphinxql->escape_string($query[4])."',{$query[5]},'".$this->sphinxql->escape_string($query[6])."','".$this->sphinxql->escape_string($query[7])."',{$query[8]},{$query[9]},{$query[10]})";
			//file_put_contents('/tmp/query_log.txt', $query."\n", FILE_APPEND);
			$res = $this->sphinxql->query($query);
			$out[$id] = array('latency' => microtime(true) - $t);
		}
		return $out;
	}

	public static function report($queriesInfo) {
		return array('Count' => count($queriesInfo));
	}
}
