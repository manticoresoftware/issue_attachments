<?php
class plugin {

	private $sphinxql = false;

	public function init() {
//		$ports = array(10300,10400,10500);
		$this->sphinxql = new mysqli('127.0.0.1', '', '', '', 10300/*$ports[rand(0,2)]*/);
	}

	public function query($queries) {
		$out = array();
		foreach ($queries as $id=>$query) {
			$t = microtime(true);
			$query = "replace into pq(id,query) values(".crc32($query).", '{$query}')";
			$res = $this->sphinxql->query($query);
			$out[$id] = array('latency' => microtime(true) - $t);
		}
		return $out;
	}

	public static function report($queriesInfo) {
		return array('Count' => count($queriesInfo));
	}
}
