#!/bin/bash

[ ! -x ../config ] && echo "./config not found or not executable. Copy from ./config_example and edit" && exit 1

. ../config

[[ "$storages" != *"elastic"* ]] && echo "ERROR: cannot run. Make sure env. var. storages contains elastic" && exit 1
[ -z "$storage_elastic_host" ] && echo "ERROR: storage_elastic_host env. var is not specified" && exit 1
[ -z "$storage_elastic_port" ] && echo "ERROR: storage_elastic_port env. var is not specified" && exit 1
[ -z "$storage_elastic_user" ] && echo "ERROR: storage_elastic_user env. var is not specified" && exit 1
[ -z "$storage_elastic_password" ] && echo "ERROR: storage_elastic_password env. var is not specified" && exit 1
[ -z "$storage_kibana_port" ] && echo "ERROR: storage_kibana_port env. var is not specified" && exit 1

docker-compose $@
