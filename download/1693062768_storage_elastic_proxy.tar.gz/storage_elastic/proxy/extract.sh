#!/bin/sh
cat req_dump.log.har|jq -c '.log.entries[].request | select(. | has("postData")) | select(.url | contains("_search")) | select(.url | contains("kibana") | not) | select(.url | contains("reporting") | not) | select(.url | contains("basic_concurrency_queries")) | {url: .url, data: .postData.text|fromjson}'
