#!/bin/bash
cd "$(dirname "$0")"

./docker-compose.sh stop elasticsearch
tar -czf es_data_`date +%Y%m%d_%H%M%S`.tgz es_data
./docker-compose.sh start elasticsearch
find es_data_*tgz -mtime +7 -delete
