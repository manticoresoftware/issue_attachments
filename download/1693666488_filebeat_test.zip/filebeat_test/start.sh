#!/bin/bash

sed -i 's~listen = $ip:9315-9325:replication~listen = $ip:9315-9325:replication\n    buddy_path = /usr/bin/manticore-executor -n /usr/share/manticore/modules/manticore-buddy/src/main.php --debug~g' /etc/manticoresearch/manticore.conf
EXTRA=1 /usr/local/bin/docker-entrypoint.sh searchd 
nohup filebeat -c filebeat.yml -e -strict.perms=false 2>/dev/null & 
sleep 5
cat /var/log/manticore/searchd.log
