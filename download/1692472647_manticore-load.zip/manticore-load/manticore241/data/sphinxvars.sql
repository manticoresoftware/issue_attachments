CREATE FUNCTION uniqfacetint RETURNS BIGINT SONAME 'udfrozetka.so';
CREATE FUNCTION isunique RETURNS INT SONAME 'udfrozetka.so';