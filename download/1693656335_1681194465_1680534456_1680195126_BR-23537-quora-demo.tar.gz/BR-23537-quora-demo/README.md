
Generate indexes on SE nodes:

```shell
docker-compose exec se-5 indexer --rotate --all
docker-compose exec se-6 indexer --rotate --all
```

```shell
docker-compose exec se-5 searchd
docker-compose exec se-6 searchd
```
