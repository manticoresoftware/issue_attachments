<?php
//echo '{"test":1, "version":1, "type":"json response", "message":1}';
echo <<<'EOD' {"version":1,"type":"sql response","message":[{"total":0,"warning":"","error":"sphinxql: syntax error, unexpected identifier near 'abc'"}],"error":"sphinxql: syntax error, unexpected identifier near 'abc'"} EOD;

//WARNING: [BUDDY] [8] syntax error, unexpected '}' near '"message":}': {"test":1, "version":1, "type":"json response", "message":}
//WARNING: [BUDDY] [9] syntax error, unexpected '}' near '"message":}': {"test":1, "version":1, "type":"json response", "message":}

return true;
?>