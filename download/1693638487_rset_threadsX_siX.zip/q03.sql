SELECT id, title, clear_price, cost_price, vat, gtin, quantity, new_price, link, image_link, brand_id, availability, products_in_stock, manual_price, shipping_price, favorite, price_strategy_id, price_strategy_id, matchings_data.count as matchings_data_count, matchings_data_count > 0 as hasmatch, matchings_data.average as average_price, matchings_data.median as median_price, DOUBLE(stored_properties.gross_margin) as gross_margin, DOUBLE(stored_properties.new_gross_margin) as new_gross_margin, DOUBLE(stored_properties.gross_profit) as gross_profit, DOUBLE(stored_properties.new_gross_profit) as new_gross_profit, stored_properties.strategy_minimum_price as strategy_minimum_price, google_analytics_data.30.cost as cost, google_analytics_data.30.conversion_rate as conversion_rate, INTEGER(google_analytics_data.30.visitors) as visitors, google_analytics_data.30.sales_x100 as sales, INTEGER(google_analytics_data.30.quantity) as number_of_sales, INTEGER(google_analytics_data.30.clicks) as clicks, google_analytics_data.30.profit_without_vat_x100 as profit, google_analytics_data.weeks_on_hand as weeks_on_hand, google_analytics_data.last_sale_date as last_sale_date, dynamic_tag_data, price_strategies_data, labels_data, INTEGER(matchings_data.count) as diff, ((LENGTH(matchings_data.competitors_availability['in stock']))) as competitors_count, JSON_FILTER(matchings_data.competitors, '{"availability":["in stock"]}', matchings_data.json_udf_indexes, account_id, 11669) as filtered_competitors, LENGTH(filtered_competitors) as filtered_competitors_length, JSON_OBJECTS_AGG_BY_KEY(filtered_competitors, 'id') as matchings_data_ids, PRICE_COLOR(filtered_competitors, '{"lowest":{"maxDiff":0,"color":"green-price","title":"Lowest price","show":true,"count":0,"disabled":false},"highest":{"minDiff":0,"color":"red-price","title":"Highest price","show":true,"count":0,"disabled":false},"neutral":{"color":"gray-price","title":"Neutral price","maxDiff":0,"minDiff":0,"show":true,"count":29809,"disabled":false},"semiLow":{"disabled":true,"semi":true,"color":"light-green-price","title":"Semi low price","maxDiff":0,"minDiff":0,"show":true,"count":0},"semiHigh":{"disabled":true,"semi":true,"color":"yellow-price","title":"Semi high price","maxDiff":0,"minDiff":0,"show":true,"count":0}}') as price_color
FROM products_index
WHERE account_id = 11669 AND filtered_competitors_length > 3 
ORDER BY hasmatch DESC, diff DESC LIMIT 0, 10 OPTION max_matches = 5000
FACET matchings_data.domain_ids ORDER BY count(*) desc, id asc LIMIT 0, 5000
FACET labels_data.ids LIMIT 0, 5000 
FACET product_type_id LIMIT 0, 5000 
FACET brand_id LIMIT 0, 5000 
FACET favorite ORDER BY favorite ASC 
FACET stored_properties.gross_margin_color ORDER BY stored_properties.gross_margin_color ASC 
FACET STR_TO_STR(price_color) as _price_status ORDER BY _price_status ASC 
FACET custom_labels_data.values LIMIT 0, 5000 
FACET price_strategy_id LIMIT 0, 5000 
FACET matchings_data IS NOT NULL as has_match ORDER BY matchings_data.count ASC 
FACET IF(manual_price > 0, 1, 0) as has_manual_price 
FACET IF(new_price > 0, 1, 0) as has_new_prices 
FACET IF(availability =  'out of stock', 0, IF(availability =  'preorder', 1, 2)) as stock_status 
FACET dynamic_tag_data.ids LIMIT 0, 5000 
FACET matchings_data.competitors_availability.hasInStock AS alias_competitorsavailabilityinstock 
FACET matchings_data.competitors_availability.hasOutOfStock AS alias_hasoutofstockcompetitors 
FACET matchings_data.competitors_availability['in stock'] LIMIT 0, 5000 
FACET INTEGER(competitors_count) LIMIT 0, 9999999999 
FACET 1;
show meta;