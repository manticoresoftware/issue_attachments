#!/bin/bash

i=1
total=10000
#dump="kafka_reddit.dump"
dump="kafka_gen.dump"
brokers="localhost:9192,localhost:9292,localhost:9392"
topic="reddit_pq_combined_stream_ms"
#topic="reddit_prod_premium_out"

cat $dump | while read json; do
    #echo ">>> [$i/$total] $json"
    echo ">>> [$i/$total]"
    echo "$json" | kcat -b "$brokers" -P -t "$topic"
    i=$(($i+1))
done
