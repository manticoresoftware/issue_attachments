#!/bin/bash

lines=10000

# [optional] validate the string is valid json
for i in `seq 1 $lines`; do
    title="title another one"
    [[ $(($i % 2)) -eq 0 ]] && title="title just in case"

    body="body another one"
    [[ $(($i % 2)) -eq 0 ]] && body="body just in case"

    url="https://google.com/test"
    [[ $(($i % 2)) -eq 0 ]] && url="https://youtube.com/test"

    echo "{\"id\":\"$i\",\"title\":\"$title\",\"body\":\"$body\",\"url\":\"$url\"}"
done
