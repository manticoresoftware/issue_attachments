# Create topic

```
docker-compose exec kafka01 kafka-topics.sh --zookeeper zookeeper:2181 --topic reddit_pq_combined_stream_ms --create --partitions 8 --replication-factor 1
```


# Produce posts to topic

```
kcat -b localhost:9192,localhost:9292,localhost:9392 -P -t reddit_pq_combined_stream_ms -l kafka_reddit.dump
```

# Count of posts in topic

```
kcat -b localhost:9192,localhost:9292,localhost:9392 -C -t reddit_pq_combined_stream_ms -e -q | grep -v "Reading configuration from file" | wc -l
```

## Test 1

```
docker-compose exec kafka01 kafka-topics.sh --zookeeper zookeeper:2181 --topic reddit_pq_combined_stream_ms --delete
docker-compose exec kafka01 kafka-topics.sh --zookeeper zookeeper:2181 --topic reddit_prod_premium_out --delete
docker-compose exec kafka01 kafka-topics.sh --zookeeper zookeeper:2181 --topic pquery.reddit.94b4110188387ba09e35ac317a0e8d4a.out --delete
```

```
docker-compose exec kafka01 kafka-topics.sh --zookeeper zookeeper:2181 --topic reddit_pq_combined_stream_ms --create --partitions 8 --replication-factor 1
docker-compose exec kafka01 kafka-topics.sh --zookeeper zookeeper:2181 --topic reddit_prod_premium_out --create --partitions 8 --replication-factor 1
docker-compose exec kafka01 kafka-topics.sh --zookeeper zookeeper:2181 --topic pquery.reddit.94b4110188387ba09e35ac317a0e8d4a.out --create --partitions 8 --replication-factor 1
```
