#include "sphinxudf.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>  

int json_filter_bool_ver()
{
    return SPH_UDF_VERSION;
}

int json_filter_bool_init ( SPH_UDF_INIT *init, SPH_UDF_ARGS *args, char *error_message )
{
    return 0;
}

sphinx_int64_t json_filter_bool ( SPH_UDF_INIT *init, SPH_UDF_ARGS * args, int *length, char *error_flag )
{
	return 1;
}

void json_filter_bool_deinit(SPH_UDF_INIT * init) 
{

}
