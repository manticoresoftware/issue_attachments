#include "sphinxudf.h"

#ifdef _MSC_VER
#define snprintf _snprintf
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT
#endif

DLLEXPORT int str_test_ver()
{
    return SPH_UDF_VERSION;
}

DLLEXPORT int str_test_init ( SPH_UDF_INIT *init, SPH_UDF_ARGS *args, char *error_message )
{
    // return a success code
    return 0;
}


DLLEXPORT char* str_test ( SPH_UDF_INIT *init, SPH_UDF_ARGS * args, char *error_flag )
{	
	char * out;
	
	out = args->fn_malloc(2 + 1);
	out[0] = '[';
	out[1] = ']';
	out[2] = '\0';

	return out;
}

void str_test_deinit(SPH_UDF_INIT * init) 
{
	
}