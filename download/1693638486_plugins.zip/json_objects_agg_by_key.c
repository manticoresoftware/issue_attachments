#include "sphinxudf.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "cJSON.h"

#ifdef _MSC_VER
#define snprintf _snprintf
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT
#endif

DLLEXPORT int json_objects_agg_by_key_ver()
{
    return SPH_UDF_VERSION;
}

DLLEXPORT int json_objects_agg_by_key_init ( SPH_UDF_INIT *init, SPH_UDF_ARGS *args, char *error_message )
{
	if ( args->arg_count != 2 )
	{
		snprintf ( error_message, SPH_UDF_ERROR_LEN, "Function JSON_OBJECTS_AGG_BY_KEY must take 2 arguments" );
		return 1;
	}

    // return a success code
    return 0;
}


//json_objects_agg_by_key(json, 'key')
DLLEXPORT char* json_objects_agg_by_key ( SPH_UDF_INIT *init, SPH_UDF_ARGS * args, char *error_flag )
{
	const cJSON *resultString = NULL;
	cJSON * jsonArray = cJSON_ParseWithLength(args->arg_values[0], args->str_lengths[0]);
	char * aggKey = args->arg_values[1];
	
	cJSON *iterator = NULL;
	cJSON *jsonObjectKeyValue = NULL;

	cJSON *resultData = cJSON_CreateArray();
	char * resString;

	cJSON_ArrayForEach(iterator, jsonArray) {
		jsonObjectKeyValue = cJSON_GetObjectItemCaseSensitive(iterator, aggKey);

		if (jsonObjectKeyValue) {
			cJSON_AddItemToArray(resultData, cJSON_Duplicate(jsonObjectKeyValue, 1));
		}
	}		

	resString = cJSON_Print(resultData);
	cJSON_Delete(resultData);
	cJSON_Minify(resString);

	char *result = (char *)args->fn_malloc(sizeof(char) * strlen(resString) + 30);
    strcpy(result, resString);
    return result;
}

DLLEXPORT void json_objects_agg_by_key_deinit(SPH_UDF_INIT * init) 
{
	 // deallocate storage
      if ( init->func_data )
      {
        free ( init->func_data );
      }
}