#include "sphinxudf.h"
#include <string.h>
#include <stdio.h>

#ifdef _MSC_VER
#define snprintf _snprintf
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT
#endif

sphinx_log_fn* sphlog = NULL;

void UdfLog ( char * szMsg );
void UdfLogInt ( int number );

/// UDF set logging callback
/// gets called once when the library is loaded; daemon set callback function in this call
DLLEXPORT void str_to_str_setlogcb ( sphinx_log_fn* cblog )
{
	sphlog = cblog;
}

DLLEXPORT int str_to_str_ver()
{
    return SPH_UDF_VERSION;
}

DLLEXPORT int str_to_str_init ( SPH_UDF_INIT *init, SPH_UDF_ARGS *args, char *error_message )
{
    // return a success code
    return 0;
}

//STR_TO_STR(string)
DLLEXPORT char* str_to_str ( SPH_UDF_INIT *init, SPH_UDF_ARGS * args, int *length, char *error_flag )
{		
	char * result = (char *)args->fn_malloc(sizeof(char) * (args->str_lengths[0] + 1));
	memcpy(result, (char *)args->arg_values[0], args->str_lengths[0]);
	result[args->str_lengths[0]] = '\0';
    return result;
}

DLLEXPORT void str_to_str_deinit(SPH_UDF_INIT * init) 
{
	
}

void UdfLog ( char * szMsg )
{
	if ( sphlog )
		( *sphlog ) ( szMsg, -1 );
}

void UdfLogInt ( int number )
{
	char n[50];
	sprintf(n, "%d", number);
	UdfLog(n);
}