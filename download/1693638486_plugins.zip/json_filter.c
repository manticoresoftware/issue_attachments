#include "sphinxudf.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>  
#include <time.h>
#include "cJSON.h"

#define ENABLE_LOGGING 0
#define ENABLE_TIMING 0

#ifdef _MSC_VER
#define snprintf _snprintf
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT
#endif

sphinx_log_fn* sphlog = NULL;

/// UDF set logging callback
/// gets called once when the library is loaded; daemon set callback function in this call
DLLEXPORT void json_filter_setlogcb ( sphinx_log_fn* cblog )
{
	sphlog = cblog;
}

typedef struct Array{
  int *array;
  size_t used;
  size_t size;
} Array;

typedef struct PointerArray{
  struct Array **pointersArray;
  size_t used;
  size_t size;
} PointerArray;

void UdfLog (char * szMsg);
void UdfLogF (char );
void UdfLogInt (int number);
void UdfLogMyArray(Array * arr);
void UdfLogPointerArray(PointerArray * arr);


DLLEXPORT int json_filter_ver()
{
    return SPH_UDF_VERSION;
}

DLLEXPORT int json_filter_init ( SPH_UDF_INIT *init, SPH_UDF_ARGS *args, char *error_message )
{
    // return a success code
    return 0;
}

//Array 
void initArray(Array *a, size_t initialSize);
void insertArray(Array *a, int element);
void removeArrayDuplicates(Array *a);
void printMyArray(struct Array * arr);
void freeArray(Array *a);

//PointersArray
void initPointersArray(PointerArray *a);
void insertPointersArray(PointerArray *a, Array * pointerArray);
void freePointersArray(PointerArray *a);
int isAnyOfPointersArraysEmpty(PointerArray * arr);

//Ids must be sorted for binary search
int binarySearchCJSONIntegerArray(cJSON * searchIds, int key);

void intersectionOfArrays(struct Array * arr1, struct Array * arr2, struct Array * out);
int searchCJSONStringArray(cJSON * searchIds, char *key);

DLLEXPORT char* json_filter ( SPH_UDF_INIT *init, SPH_UDF_ARGS * args, char *error_flag )
{	
	int rowAccountId = *(int*)args->arg_values[3];
	int currentAccountId = *(int*)args->arg_values[4];

	//Function work on other accounts too(weird but thats how it is), thats why we early exit if row is in other account
	if ((rowAccountId != currentAccountId) || !args->arg_values[0])
	{
		char * resultString = "[]";
		char *result = (char *)args->fn_malloc(sizeof(char) * strlen(resultString) + 20);
    	strcpy(result, resultString);
    	return result;
	}

	cJSON * filterObj = NULL;	
	char * filterKey;
	cJSON * filterId = NULL;

	cJSON * indexObj = NULL;
	cJSON * indexKey = NULL;

	cJSON * filters = cJSON_ParseWithLength(args->arg_values[1], args->str_lengths[1]);

	cJSON * filterKeysToDelete = cJSON_CreateArray();
	cJSON * filterKeyToDelete = NULL;

	bool foundIndex = false;

	Array idsArray;
	initArray(&idsArray, 1);

 	PointerArray pointerArrays;
 	initPointersArray(&pointerArrays);

	//Index field, example {"domain_id": {"search_ids": [2495, 2869, 3102, 3683, 8525, 57932], "related_ids": [1464267394, 1477490211, 1464267854, 1464267399, 1464363997, 1473601973]}}
	if (args->arg_values[2]) {
		cJSON * indexData = cJSON_ParseWithLength(args->arg_values[2], args->str_lengths[2]);

		int filterCounter = 0;
		cJSON_ArrayForEach(filterObj, filters) {
			// UdfLog("BEFORE MALLOC");
			Array * tmpArray = malloc(sizeof(struct Array));
			// UdfLog("AFTER MALLOC");
			initArray(tmpArray, 1);

			//Just the example, can be other index
			//domain_id
			filterKey = filterObj->string;
			if (!filterKey) {
				break;
			}

			//type
			//{"search_ids": [2495, 2869, 3102, 3683, 8525, 57932], "related_ids": [1464267394, 1477490211, 123123123, 6151168121, 1464267854, 1464267399, 1464363997, 1473601973]}
			//or
			//{"search_ids": ["default", "googleShopping", "manualCompetitors"], "related_ids": [[1464267394, 1477490211, 123123123], [6151168121, 1464267854, 1464267399], [1464363997, 1473601973]}

			indexObj = cJSON_GetObjectItemCaseSensitive(indexData, filterKey);
			if (!indexObj) {
				break;
			}

			foundIndex = true;

			cJSON * searchIds = cJSON_GetObjectItemCaseSensitive(indexObj, "search_ids");
			cJSON * relatedIds = cJSON_GetObjectItemCaseSensitive(indexObj, "related_ids");

			//If index search_ids is empty then early exit;
			if (cJSON_GetArraySize(searchIds) == 0) {
				freeArray(&idsArray);
				cJSON_Delete(filters);
				char * resultString = "[]";
				char *result = (char *)args->fn_malloc(sizeof(char) * strlen(resultString) + 2);
				strcpy(result, resultString);
				return result;
			}

			cJSON_ArrayForEach(filterId, filterObj) {
				int foundId = -1;
				switch(filterId->type) {
				  case cJSON_String:
				    foundId = searchCJSONStringArray(searchIds, filterId->valuestring);
				    break;
				  //Integer
				  case 8:
				    foundId = binarySearchCJSONIntegerArray(searchIds, filterId->valueint);
				    break;
				}

				//Found id can be integer if its ONE TO ONE relation or an array of integers if its ONE TO MANY relation
				//"related_ids": [1464267394, 1477490211, 123123123, 6151168121, 1464267854, 1464267399, 1464363997, 1473601973]
				//"related_ids": [[1464267394, 1477490211, 123123123], [6151168121, 1464267854, 1464267399], [1464363997, 1473601973]
				if (foundId >= 0) {
					cJSON * relatedIdValue = cJSON_GetArrayItem(relatedIds, foundId);
					cJSON * idValue = NULL;

					switch(relatedIdValue->type) {
					  case cJSON_Array:
					  	cJSON_ArrayForEach(idValue, relatedIdValue) {
					  		insertArray(tmpArray, idValue->valueint);
					  	}

					    break;
					  //Integer
					  case 8:
					    insertArray(tmpArray, relatedIdValue->valueint);
					    break;
					}
				}
			}

			insertPointersArray(&pointerArrays, tmpArray);

			//If index was found, adding it to array which will get removed from main filters
			cJSON_AddItemToArray(filterKeysToDelete, cJSON_CreateString(filterKey));
		}

		//Removing filter objects which has index from filters
		cJSON_ArrayForEach(filterKeyToDelete, filterKeysToDelete) {
			cJSON_DeleteItemFromObjectCaseSensitive(filters, filterKeyToDelete->valuestring);
		}

		cJSON_Delete(filterKeysToDelete);
		cJSON_Delete(indexData);

		//Early exit, if index was found but didnt find any ids matched between filter values and index values
		if (foundIndex && isAnyOfPointersArraysEmpty(&pointerArrays)) {
			freeArray(&idsArray);
			cJSON_Delete(filters);
			char * resultString = "[]";
			char *result = (char *)args->fn_malloc(sizeof(char) * strlen(resultString) + 2);
    		strcpy(result, resultString);
    		return result;
		}
	}

	//Search intersection of ids from found indexes ids
	if (pointerArrays.used > 1) {
	 	for (int k = 0; k < (pointerArrays.used - 1); k++) {
	 		if (k == 0) {
	 			intersectionOfArrays(pointerArrays.pointersArray[k], pointerArrays.pointersArray[k + 1], &idsArray);
	 		} else {
	 			intersectionOfArrays(&idsArray, pointerArrays.pointersArray[k + 1], &idsArray);
	 		}
			
	 	}
	} else if (pointerArrays.used == 1) {
		for(int k = 0; k < pointerArrays.pointersArray[0]->used; k++) {
			insertArray(&idsArray, pointerArrays.pointersArray[0]->array[k]);
		}
	}

 	freePointersArray(&pointerArrays);

	//Parsing main data array
	cJSON * jsonDataArray = cJSON_ParseWithLength(args->arg_values[0], args->str_lengths[0]);

	cJSON * resultData = cJSON_CreateArray();
	cJSON * iterator = NULL;
	cJSON * iteratorFilterValue = NULL;
	cJSON * iteratorValue = NULL;
	char * resultString;

	//If index was found, filter by index ids first
	if (foundIndex) {
		int i;
		int filtersSize = cJSON_GetArraySize(filters);

		for(i = 0; i < idsArray.used; i++) {
			char id[20];
			sprintf(id, "%d", idsArray.array[i]);
			char *pId = id;
			iterator = cJSON_GetObjectItemCaseSensitive(jsonDataArray, pId);

			bool addToResult = true;

			//If all data was found by index, use ids which was find at index
			if (filtersSize == 0) {
				cJSON_AddItemReferenceToArray(resultData, iterator);
			} else {
				cJSON_ArrayForEach(filterObj, filters) {
					iteratorValue = cJSON_GetObjectItemCaseSensitive(iterator, filterObj->string);

					if (!iteratorValue) {
						addToResult = false;
						break;
					}

					bool foundMatch = false;
					cJSON_ArrayForEach(iteratorFilterValue, filterObj) {
						char * a = cJSON_Print(iteratorValue);
						char * b = cJSON_Print(iteratorFilterValue);
						if (strcmp(a, b) == 0) {
							foundMatch = true;

							free(a);
							free(b);
							break;
						}

						free(a);
						free(b);
					}

					if (!foundMatch) {
						addToResult = false;
						break;
					}
				}

				if (addToResult) {
					cJSON_AddItemReferenceToArray(resultData, iterator);
				}

				cJSON_AddItemReferenceToArray(resultData, iterator);
			}
		}

		//If index was not found using foreach to all products and filters
	} else {
		cJSON_ArrayForEach(iterator, jsonDataArray) {
			bool addToResult = true;
			cJSON_ArrayForEach(filterObj, filters) {
				iteratorValue = cJSON_GetObjectItemCaseSensitive(iterator, filterObj->string);

				if (!iteratorValue) {
					addToResult = false;
					break;
				}

				bool foundMatch = false;
				cJSON_ArrayForEach(iteratorFilterValue, filterObj) {
					if (strcmp(cJSON_Print(iteratorValue), cJSON_Print(iteratorFilterValue)) == 0) {
						foundMatch = true;
						break;
					}

				}

				if (!foundMatch) {
					addToResult = false;
					break;
				}
			}

			if (addToResult) {
				cJSON_AddItemReferenceToArray(resultData, iterator);
			}
		}	
	}


	resultString = cJSON_Print(resultData);

	//Removing created cJSON arrays and objects, important otherwise will be memory leaks
	cJSON_Delete(resultData);
	cJSON_Delete(jsonDataArray);
	cJSON_Delete(filters);
	freeArray(&idsArray);
	
	cJSON_Minify(resultString);

	char *result = (char *)args->fn_malloc(sizeof(char) * strlen(resultString) + 30);
    strcpy(result, resultString);
    free(resultString);
    return result;
}

DLLEXPORT void json_filter_deinit(SPH_UDF_INIT * init) 
{
	
}

//Log functions
void UdfLog ( char * szMsg )
{
	if (ENABLE_LOGGING == 0) {
		return;
	}

	if ( sphlog )
		( *sphlog ) ( szMsg, -1 );

	if (ENABLE_TIMING == 1) {
		char time[50];

		sprintf(time, "Timestamp - %f", ((double)clock())/CLOCKS_PER_SEC);

		if ( sphlog )
		( *sphlog ) ( time, -1 );
	}
}

void UdfLogInt ( int number )
{
	char n[50];
	sprintf(n, "%d", number);
	UdfLog(n);
}

void UdfLogMyArray(Array * arr) {
	char n[500];
	char *pos = n;
	char used[20];
	char size[20];

	UdfLog("-- UdfLogMyArray");
	sprintf(used, "Used - %ld", arr->used);
	sprintf(size, "Size - %ld", arr->size);
	UdfLog(used);
	UdfLog(size);
	if (arr->used == 0) {
		UdfLog("Array empty");
		return;
	}

	UdfLog("Printing Array");

	int i;
	for(i = 0; i < arr->used; i++) {
      pos += sprintf(pos, "%d ", arr->array[i]);
	}
	UdfLog(n);

	UdfLog("-- End UdfLogMyArray");
}

void UdfLogPointerArray(PointerArray * arr) {
	char used[20];
	char size[20];

	UdfLog(">> UdfLogPointerArray");

	sprintf(used, "Used - %ld", arr->used);
	sprintf(size, "Size - %ld", arr->size);
	UdfLog(used);
	UdfLog(size);
	if (arr->used == 0) {
		UdfLog("PointerArray empty");
		return;
	}

	UdfLog("Printing PointerArray");

	int i;
	for(i = 0; i < arr->used; i++) {
      UdfLogMyArray(arr->pointersArray[i]);
	}
	
	UdfLog(">> End UdfLogPointerArray");
}

// Array -----------------------
void initArray(Array *a, size_t initialSize) {
  a->array = malloc(initialSize * sizeof(int));
  a->used = 0;
  a->size = initialSize;
}

void insertArray(Array *a, int element) {
  // a->used is the number of used entries, because a->array[a->used++] updates a->used only *after* the array has been accessed.
  // Therefore a->used can go up to a->size 
  if (a->used == a->size) {
    // a->size *= 2;
    a->size = (a->size * 3)/2 + 8;
    a->array = realloc(a->array, a->size * sizeof(int));
  }
  a->array[a->used++] = element;
}

void removeArrayDuplicates(Array *a) {
 	int i, j, k;  

	// use nested for loop to find the duplicate elements in array  
    for ( i = 0; i < a->used; i ++)  
    {  
        for ( j = i + 1; j < a->used; j++)  
        {  
            // use if statement to check duplicate element  
            if ( a->array[i] == a->array[j])  
            {  
                // delete the current position of the duplicate element  
                for ( k = j; k < a->used - 1; k++)  
                {  
                    a->array[k] = a->array [k + 1];  
                }  
                // decrease the size of array after removing duplicate element  
                a->used--;  
                  
            // if the position of the elements is changes, don't increase the index j  
                j--;      
            }  
        }  
    }  
};

void printMyArray(Array * arr) {
	UdfLog("printMyArray");
	UdfLogInt(arr->used);

	int i;
	for(i = 0; i < arr->used; i++) {
      printf("%d ", arr->array[i]);
	}
	printf("\n");
}

void freeArray(Array *a) {
  free(a->array);
  a->array = NULL;
  a->used = a->size = 0;
}


//PointerArray --------------------------
void initPointersArray(PointerArray *a) {
  a->pointersArray = malloc(sizeof(Array));
  a->used = 0;
  a->size = 3;
}

void insertPointersArray(PointerArray *a, Array * pointerArray) {
  // a->used is the number of used entries, because a->array[a->used++] updates a->used only *after* the array has been accessed.
  // Therefore a->used can go up to a->size 
  if (a->used == a->size) {
    // a->size *= 2;
    a->size = (a->size * 3)/2 + 8;
    a->pointersArray = realloc(*a->pointersArray, a->size * sizeof(pointerArray));
  }

  a->pointersArray[a->used++] = pointerArray;
}

int isAnyOfPointersArraysEmpty(PointerArray * arr) {
	for (int i = 0; i < arr->used; i++) {
		if (arr->pointersArray[i]->used == 0) {
			return 1;
		}
	}

	return 0;
}

void freePointersArray(PointerArray *a) {
	for (int i = 0; i < a->used; i++) {
		freeArray(a->pointersArray[i]);
	}


  free(a->pointersArray);
  a->pointersArray = NULL;
  a->used = a->size = 0;
}

//----------------

int binarySearchCJSONIntegerArray(cJSON * searchIds, int key) {
	if (cJSON_GetArrayItem(searchIds, 0)->valueint > key) {
		return -1;
	}

	int searchIdsLength = cJSON_GetArraySize(searchIds);

	if (cJSON_GetArrayItem(searchIds, searchIdsLength - 1)->valueint < key) {
		return -1;
	}

	int low = 0;
	int high = searchIdsLength - 1;
	int mid = (low+high)/2;

	while (low <= high) {
		int currentSearchId = cJSON_GetArrayItem(searchIds, mid)->valueint;
		if(currentSearchId < key) { 
			low = mid + 1;
		}
		else if (currentSearchId == key) {
			return mid;
			break;
		} else {
			high = mid - 1;
		}

		mid = (low + high)/2;
		
	}

	if(low > high) {
		return -1;
	}

	return -1;
}

void intersectionOfArrays(struct Array * arr1, struct Array * arr2, struct Array * out) {
  int i = 0, j = 0;

  while(i < arr1->used && j < arr2->used)
  {
  	// printf("arr1->array[i] = %d, arr2->array[j] = %d \n", arr1->array[i], arr2->array[j]);
    if(arr1->array[i] < arr2->array[j])
      i++;
    else if(arr2->array[j] < arr1->array[i])
      j++;
    else /* if arr1[i] == arr2[j] */
    {
      insertArray(out, arr2->array[j]);
      j++;
      i++;
    }
  }
}

int searchCJSONStringArray(cJSON * searchIds, char *key) {
	cJSON *value = NULL;
	int counter = 0;

	cJSON_ArrayForEach(value, searchIds) {
		if (strcmp(value->valuestring, key) == 0) {
			return counter;
		}

		counter++;
	}

	return -1;
}