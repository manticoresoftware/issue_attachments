#include "sphinxudf.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>  
#include <time.h>
#include <math.h>
#include "cJSON.h"

#define ENABLE_LOGGING 0
#define ENABLE_TIMING 0

#ifdef _MSC_VER
#define snprintf _snprintf
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT
#endif

sphinx_log_fn* sphlog = NULL;

void UdfLog ( char * szMsg );
void UdfLogInt ( int number );
void UdfLogFloat ( float number );
void UdfLogDouble ( double number );
int compareFloat(float a, double b);

/// UDF set logging callback
/// gets called once when the library is loaded; daemon set callback function in this call
DLLEXPORT void price_color_setlogcb ( sphinx_log_fn* cblog )
{
	sphlog = cblog;
}

DLLEXPORT int price_color_ver()
{
    return SPH_UDF_VERSION;
}

DLLEXPORT int price_color_init ( SPH_UDF_INIT *init, SPH_UDF_ARGS *args, char *error_message )
{
    // return a success code
    return 0;
}

//PRICE_COLOR(competitors, rules, clear_price, quantity)
DLLEXPORT char* price_color ( SPH_UDF_INIT *init, SPH_UDF_ARGS * args, char *error_flag )
{		
	cJSON * competitors = cJSON_ParseWithLength((char *)args->arg_values[0], args->str_lengths[0]);
	cJSON * rules = cJSON_ParseWithLength((char *)args->arg_values[1], args->str_lengths[1]);

	double minCompetitorPrice = 99999;
	double minCompetitorQuantity = 0;
	double diff = 0;

	char * resultString;

	cJSON * competitor = NULL;
	cJSON_ArrayForEach(competitor, competitors) {
		cJSON * clearPrice = cJSON_GetObjectItemCaseSensitive(competitor, "clear_price");
		cJSON * quantity = cJSON_GetObjectItemCaseSensitive(competitor, "quantity");
		cJSON * priceDiff = cJSON_GetObjectItemCaseSensitive(competitor, "price_diff");

		if (minCompetitorPrice > clearPrice->valuedouble) {
		  minCompetitorPrice = clearPrice->valuedouble;
		  minCompetitorQuantity = quantity->valuedouble;
		  diff = priceDiff->valuedouble;
		}
	}

	cJSON * lowest = cJSON_GetObjectItemCaseSensitive(rules, "lowest");
	cJSON * semiLow = cJSON_GetObjectItemCaseSensitive(rules, "semiLow");
	cJSON * neutral = cJSON_GetObjectItemCaseSensitive(rules, "neutral");
	cJSON * semiHigh = cJSON_GetObjectItemCaseSensitive(rules, "semiHigh");
	cJSON * highest = cJSON_GetObjectItemCaseSensitive(rules, "highest");

	if (!cJSON_GetArraySize(competitors)) {
		resultString = "NULL";

		cJSON_Delete(competitors);
		cJSON_Delete(rules);
		char * result = (char *)args->fn_malloc(strlen(resultString) + 1);
	    strcpy(result, resultString);
	    result[strlen(resultString)] = '\0';
	    return result;
	}

	if (!rules || !cJSON_GetArraySize(rules)) {
		if (diff > 0) {
		  resultString = "green-price";
		} else if (diff < 0) {
		  resultString = "red-price";
		} else {
		  resultString = "gray-price";
		}

		char * rr = "a";
		char * result = (char *)args->fn_malloc(strlen(resultString) + 1);
	    strcpy(result, resultString);
	    result[strlen(resultString)] = '\0';
	    return result;
	}

	if (diff > abs(cJSON_GetObjectItemCaseSensitive(lowest, "maxDiff")->valuedouble)) {
		resultString = "green-price";
	} else if (semiLow && !cJSON_GetObjectItemCaseSensitive(semiLow, "disabled")->valueint && diff > abs(cJSON_GetObjectItemCaseSensitive(semiLow, "minDiff")->valuedouble) && diff <= abs(cJSON_GetObjectItemCaseSensitive(semiLow, "maxDiff")->valuedouble)) {
		resultString = "light-green-price";
	} else if (diff >= (-1 * abs(cJSON_GetObjectItemCaseSensitive(neutral, "maxDiff")->valuedouble)) && diff <= abs(cJSON_GetObjectItemCaseSensitive(neutral, "minDiff")->valuedouble)) {
		resultString = "gray-price";
	} else if (semiHigh && !cJSON_GetObjectItemCaseSensitive(semiHigh, "disabled")->valueint && diff > (-1 * abs(cJSON_GetObjectItemCaseSensitive(semiHigh, "minDiff")->valuedouble)) && diff < (-1 * abs(cJSON_GetObjectItemCaseSensitive(semiHigh, "maxDiff")->valuedouble))) {
		resultString = "yellow-price";
	} else {
		resultString = "red-price";
	}

	cJSON_Delete(competitors);
	cJSON_Delete(rules);
	char * result = (char *)args->fn_malloc(sizeof(char) * strlen(resultString));
    strcpy(result, resultString);
    return result;
}

DLLEXPORT void price_color_deinit(SPH_UDF_INIT * init) 
{
	UdfLog("De init");
}

//Log functions
void UdfLog ( char * szMsg )
{
	if (ENABLE_LOGGING == 0) {
		return;
	}

	if ( sphlog )
		( *sphlog ) ( szMsg, -1 );

	if (ENABLE_TIMING == 1) {
		char time[50];

		sprintf(time, "Timestamp - %f", ((double)clock())/CLOCKS_PER_SEC);

		if ( sphlog )
		( *sphlog ) ( time, -1 );
	}
}

void UdfLogInt ( int number )
{
	char n[50];
	sprintf(n, "%d", number);
	UdfLog(n);
}

void UdfLogFloat ( float number )
{
	char n[50];
	sprintf(n, "%f", number);
	UdfLog(n);
}

void UdfLogDouble ( double number )
{
	char n[50];
	sprintf(n, "%f", number);
	UdfLog(n);
}

int compareFloat(float a, double b) {
	return abs(a - b) <= 0.0001;
}