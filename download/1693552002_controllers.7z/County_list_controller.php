<?php
/**
 * Controller for displaying states county list.
 * @package controllers
 */
class County_list_controller extends General_controller {
	
	use Job_list_fragment;

	const META_TOP_COUNTIES_COUNT = 3;
	const META_TOP_CITIES_COUNT = 3;
	
	/**
	 * List states county that have jobs.
	 */
	public function list_job_state_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$default_lang = App_language::get_default_general_language($db);
		$domain = $this->_global_environment->get_domain();
		$opt_man = new Options_manager($db);
		$cache = $this->_global_environment->get_cache_storage();
		$state = new State($db, $_GET['state_id']);
		try {
			$state->init(array('name', 'country_id'));
		}
		catch (Not_existing_db_model_exception $e) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		if ($state->get_url_name() != $_GET['state_url_name']) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$section = $this->_get_site_section();
		$section->country = $state->get_country();
		$section->state = $state;
		$view = $this->_create_view($state->get_country(), true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'job_location_list.php', date_create('tomorrow')->format('U') - date('U'), 'state_counties_'.$state->get_id(), 'loc_lists'
		);
		if (!$view->is_include_cached('job_location_list.php')) {
			$searcher = County::get_searcher(new Db_searcher($db));
			$searcher->set_state_search($state);

			$formatter = new Job_county_list_formatter(
				Static_job_list_searcher::init_mergable_searcher(Job::get_searcher(new Db_searcher($db)), $domain, [$lang]),
				new Latest_job_manager($db, $cache),
				$this->_get_container()->get_registered('SDB'),
				[$lang]
			);
			$params = array(
				'state_url_name' => $state->get_url_name(),
				'county_id' => '<county_id>',
				'county_url_name' => '<county_url_name>',
				'specifying_param' => 1);
			$url_template = $this->_url_manager->get_url('job_list', 'display_county_page', $params);
			$view->locations = $formatter->format($searcher->search(), $url_template);
		}

		$formatter_builder = new Job_list_formatter_builder($this->_global_environment, $this->_url_manager, $cache);
		$list_formatter = $formatter_builder->build_job_list_formatter();
		$list_formatter->set_location_format('{short_state}(- - {city} -)');
		$location = new Location(array($state));
		$list_criteria = [$location, $lang];
		$short_job_list = new Short_job_list(
			Sphinx_job_list_searcher::get_fresh($db, $domain, $list_criteria),
			new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_STATE)
		);

		$view->jobs = $short_job_list->get_formatted_jobs($lang, 2, 4, $this->_get_ip_country(), $unformatted_jobs);
		$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(), Formatted_job_list::LOCATION_LEVEL_STATE);
		Top_job_table::assign_formatted_jobs($this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), [$location, $lang]);
		
		$backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_MAIN, 'county_list', 'list_job_state', $lang);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$current_page = $this->_get_current_site_page();
		if (!is_null($current_page)) {
			$usa_url_name = $state->get_country()->get_url_name($default_lang);
			$path_links = array(
				$this->_url_manager->get_url('job_list', 'display_country', array('country_url_name' => $usa_url_name)),
				$this->_url_manager->get_url('state_list', 'list_job_country', array('country_url_name' => $usa_url_name)),
				$this->_url_manager->get_url('job_list', 'display_state_page', array(
					'country_url_name' => $usa_url_name,
					'state_url_name' => $state->get_url_name(),
					'state_id' => $state->get_id(),
					'specifying_param' => 1
				)),
				$_SERVER['REQUEST_URI']
			);

			$view = $this->_set_site_page_meta(
				$view,
				$current_page,
				array_merge($this->_get_meta_variables($state, $view->jobs), $this->_get_cat_sub_counts($section, $list_criteria)),
				$path_links
			);
		}

		$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
		$view->set_css('job_list.css');
		$view->set_include('job_location_list', 'job_location_list.php');
		$view->set_include('content', 'job_location_list_page.php');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
		$view->display();
	}

	/**
	 * @param State $current_state
	 * @param array $formatted_jobs
	 * @return array Array of meta variables
	 */
	private function _get_meta_variables(State $current_state, array $formatted_jobs = array()) {
		$db = $this->_general_env->get_db();
		$searcher = County::get_searcher(new Db_searcher($db));
		$searcher->set_state_search($current_state);
		$counter = new Job_counter($db);
		$counties = $counter->get_top_counties(self::META_TOP_COUNTIES_COUNT, $searcher->search());
		foreach ($counties as $county) {
			$county->init(array('name'));
		}
		$top_city_list = new Top_job_city_list(
			$current_state,
			$db,
			$this->_global_environment->get_general_language(),
			$this->_get_container()->get_registered('SDB')
		);
		$top_cities = $top_city_list->get_formatted_cities($this->_url_manager, self::META_TOP_CITIES_COUNT, true);

		return array('{state}' => $current_state->get_short_name(), '{state_abbr}' => $current_state->get_abbr(),
			'{county1}' => $counties[0]->name, '{county2}' => $counties[1]->name, '{county3}' => $counties[2]->name,
			'{city1}' => $top_cities[0]['name'], '{city2}' => $top_cities[1]['name'], '{city3}' => $top_cities[2]['name'],
			'{last_job_titles}' => Meta_handler::get_last_job_titles($formatted_jobs));
	}
}
