<?php
/**
 * Controller for displaying a job list.
 * For each list type two actions are needed becuase pagination requires two types of URLs.
 */
class Job_list_controller extends List_controller {

	use Job_list_fragment;

	const TOP_CAT_COUNT = 15;

	const META_TOP_CITIES_COUNT = 3;

	const COMMENTS_CACHE_TIME = 2592000;//month

	const NUM_PAGINATION_LINKS = 10;

	const LIST_BANNER_POS = 3;//desired position for list banner, can be less if list is short
	const LIST_BANNER_MIN_FOLLOW = 3;//minimum number of jobs after job list banner

	//Search Results Origins
	const SRO_PARAM = 'sro';
	const SRO_SEARCH = 'search';
	const SRO_MAIL_NOTIFICATION = 'mail_notification';
	const SRO_BROWSER_NOTIFICATION = 'browser_notification';


	/**
	 * Create page criteria models from GET parameters and assign them to a site section.
	 * @return Site_section
	 * @throws Page_not_found_exception If current URL parameters are invalid.
	 */
	private function _setup_site_section() {
		$section_builder = new \Site_section_builder(
			$this->_general_env->get_db(), $this->_global_environment->get_general_language(), $this->_global_environment->get_cache_storage()
		);
		try {
			$section = $section_builder->build_site_section($_GET, $_SERVER['REQUEST_URI']);
		}
		catch (\InvalidArgumentException $e) {
			throw new \Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		$section->is_job_list = true;

		return $section;
	}

	/**
	 * Display all jobs.
	 * Displays the first page.
	 */
	public function display_all_action() {
		$this->_display_all_page(1);
	}

	/**
	 * Display all jobs on a specific page.
	 * Works exactly like display_all_action() but specifies a page number.
	 */
	public function display_all_page_action() {
		$this->_display_all_page($_GET['page_number']);
	}

	/**
	 * Display jobs in a specific category and country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_category_country_action() {
		$this->_display_category_country_page(1);
	}

	/**
	 * Display jobs in a specific category and country on a specific page.
	 * Works exactly like display_category_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_category_country_page_action() {
		$this->_display_category_country_page($_GET['page_number']);
	}

	/**
	 * Display bachelor jobs in a specific country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_country_bachelor_action() {
		$this->_display_country_bachelor_page(1);
	}

	/**
	 * Display bachelor jobs in a specific country on a specific page.
	 * Works exactly like display_category_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_country_bachelor_page_action() {
		$this->_display_country_bachelor_page($_GET['page_number']);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_city_bachelor_action() {
		$this->_display_city_bachelor_page(1);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_city_bachelor_page_action() {
		$this->_display_city_bachelor_page($_GET['page_number']);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_state_bachelor_action() {
		$this->_display_state_bachelor_page(1);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_state_bachelor_page_action() {
		$this->_display_state_bachelor_page($_GET['page_number']);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_category_city_bachelor_action() {
		$this->_display_category_city_bachelor_page(1);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_category_city_bachelor_page_action() {
		$this->_display_category_city_bachelor_page($_GET['page_number']);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_category_state_bachelor_action() {
		$this->_display_category_state_bachelor_page(1);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_category_state_bachelor_page_action() {
		$this->_display_category_state_bachelor_page($_GET['page_number']);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_subcategory_city_bachelor_action() {
		$this->_display_subcategory_city_bachelor_page(1);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_subcategory_city_bachelor_page_action() {
		$this->_display_subcategory_city_bachelor_page($_GET['page_number']);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_subcategory_state_bachelor_action() {
		$this->_display_subcategory_state_bachelor_page(1);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_subcategory_state_bachelor_page_action() {
		$this->_display_subcategory_state_bachelor_page($_GET['page_number']);
	}

	/**
	 * Display bachelor jobs in a specific country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_category_country_bachelor_action() {
		$this->_display_category_country_bachelor_page(1);
	}

	/**
	 * Display bachelor jobs in a specific country on a specific page.
	 * Works exactly like display_category_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_category_country_bachelor_page_action() {
		$this->_display_category_country_bachelor_page($_GET['page_number']);
	}

	/**
	 * Display bachelor jobs in a specific country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_subcategory_country_bachelor_action() {
		$this->_display_subcategory_country_bachelor_page(1);
	}

	/**
	 * Display bachelor jobs in a specific country on a specific page.
	 * Works exactly like display_category_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_subcategory_country_bachelor_page_action() {
		$this->_display_subcategory_country_bachelor_page($_GET['page_number']);
	}

	/**
	 * Display jobs in a specific category and country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_subcategory_country_action() {
		$this->_display_subcategory_country_page(1);
	}

	/**
	 * Display jobs in a specific category and country on a specific page.
	 * Works exactly like display_category_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_subcategory_country_page_action() {
		$this->_display_subcategory_country_page($_GET['page_number']);
	}

	/**
	 * Display jobs in a specific category and country on a specific page.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_category_region_page_action() {
		$this->_display_category_region_page($_GET['page_number']);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_subcategory_region_action() {
		$this->_display_subcategory_region_page(1);
	}

	/**
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_subcategory_region_page_action() {
		$this->_display_subcategory_region_page($_GET['page_number']);
	}

	/**
	 * Display the most recent jobs for a specific category in several countries.
	 * @throws Page_not_found_exception if countries or a category is not provided or is disabled.
	 */
	public function display_category_multicountry_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();

		$section = $this->_setup_site_section();

		$current_countries = array();
		foreach ((array)$_GET['country_ids'] as $country_id) {
			$current_countries[] = new Country($db, $country_id);
		}
		if (empty($current_countries)) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$job_list = new Category_multicountry_job_list($this->_global_environment->get_domain(), $section->job_category, $current_countries);
		$formatter_builder = new Job_list_formatter_builder(
			$this->_global_environment, $this->_url_manager, $this->_global_environment->get_cache_storage()
		);
		$jobs = $job_list->get_formatted_jobs(
			$lang, Job::get_searcher(new Db_searcher($db)), $formatter_builder->build_job_list_formatter(), $this->_get_ip_country()
		);

		$view = $this->_get_view($jobs, null, null, true, $section);

		$current_page = $this->_get_current_site_page();
		if (!is_null($current_page)) {
			$view = $this->_set_site_page_meta($view, $current_page);
		}

		$view->display();
	}

	/**
	 * Display jobs in a specific country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid country is given or there is no jobs in given country
	 */
    public function display_country_action() {
		$this->_display_country_page(1);
	}

	/**
	 * Display jobs in a specific country on a specific page.
	 * Works exactly like display_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid country is given or there is not enough jobs to display given page
	 */
	public function display_country_page_action() {
		$this->_display_country_page($_GET['page_number']);
	}

	/**
	 * Display job category jobs in a specific city.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid parameters are given or there is no jobs with given parameters
	 */
    public function display_category_city_action() {
		$this->_display_category_city_page(1);
	}

	/**
	 * Display job category jobs in a specific city on a specific page.
	 * @throws Page_not_found_exception if invalid parameters are given or there is not enough jobs to display given page
	 */
	public function display_category_city_page_action() {
		$this->_display_category_city_page($_GET['page_number']);
	}

	/**
	 * Display job category jobs in a specific city.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid parameters are given or there is no jobs with given parameters
	 */
    public function display_category_city_old_action() {
		$this->_display_category_city_page_old();
	}

	/**
	 * Display job category jobs in a specific city on a specific page.
	 * @throws Page_not_found_exception if invalid parameters are given or there is not enough jobs to display given page
	 */
	public function display_category_city_old_page_action() {
		$this->_display_category_city_page_old();
	}

	/**
	 * Display job category jobs in a specific city.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid parameters are given or there is no jobs with given parameters
	 */
    public function display_subcategory_city_action() {
		$this->_display_subcategory_city_page(1);
	}

	/**
	 * Display job category jobs in a specific city on a specific page.
	 * @throws Page_not_found_exception if invalid parameters are given or there is not enough jobs to display given page
	 */
	public function display_subcategory_city_page_action() {
		$this->_display_subcategory_city_page($_GET['page_number']);
	}

	/**
	 * Display job category jobs in a specific city.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid parameters are given or there is no jobs with given parameters
	 */
    public function display_category_state_action() {
		$this->_display_category_state_page(1);
	}

	/**
	 * Display job category jobs in a specific city on a specific page.
	 * @throws Page_not_found_exception if invalid parameters are given or there is not enough jobs to display given page
	 */
	public function display_category_state_page_action() {
		$this->_display_category_state_page($_GET['page_number']);
	}

	/**
	 * Display jobs in a specific category and country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
    public function display_subcategory_state_action() {
		$this->_display_subcategory_state_page(1);
	}

	/**
	 * Display jobs in a specific category and country on a specific page.
	 * Works exactly like display_category_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	public function display_subcategory_state_page_action() {
		$this->_display_subcategory_state_page($_GET['page_number']);
	}

	/**
	 * Display jobs in a specific region on a specific page.
	 * @throws Page_not_found_exception if invalid region is given, ether unknown name or region without full job list.
	 */
	public function display_region_page_action() {
		$this->_display_region_page($_GET['page_number']);
	}

	/**
	 * Display jobs in a specific region (first page) and country list for that region.
	 * @throws Page_not_found_exception if invalid region is given, ether unknown name or region without full job list.
	 */
	public function display_region_action() {
		$this->_display_region_page(1);
	}

	/**
	 * Display jobs from a specific employer.
	 * Displays the first page.
	 * @throws Page_not_found_exception if employer does not exists, has no jobs, or belongs to other or unassigned domain; or has old url and
	 * this is not called from display old action
	 */
    public function display_employer_action() {
		$this->_display_employer_page(1);
	}

	/**
	 * Display jobs from a specific employer.
	 * Works exactly like display_employer_action() but specifies a page number.
	 * @throws Page_not_found_exception if employer does not exists, has no enough jobs for given page, or belongs to other or unassigned domain;
	 * or has old url and this is not called from display old action
	 */
	public function display_employer_page_action() {
		$this->_display_employer_page($_GET['page_number']);
	}

	/**
	 * Display jobs in a specific category.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid category given or there is no jobs of given category
	 */
	public function display_category_action() {
		$this->_display_category_page(1);
	}

	/**
	 * Display jobs in a specific category on a specific page.
	 * Works exactly like display_category_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid category given or there is not enough jobs for given page
	 */
	public function display_category_page_action() {
		$this->_display_category_page($_GET['page_number']);
	}

	/**
	 * Display jobs in a specific category.
	 * Displays the first page.
	 * @throws Page_not_found_exception if invalid category given or there is no jobs of given category
	 */
	public function display_subcategory_action() {
		$this->_display_subcategory_page(1);
	}

	/**
	 * Display jobs in a specific category on a specific page.
	 * Works exactly like display_category_action() but specifies a page number.
	 * @throws Page_not_found_exception if invalid category given or there is not enough jobs for given page
	 */
	public function display_subcategory_page_action() {
		$this->_display_subcategory_page($_GET['page_number']);
	}

	/**
	 * Display search form. Alias for display search results, only page number is not passed and that causes only form to be displayed.
	 */
	public function display_search_form_action() {
		$this->display_search_results_action();
	}

	/**
	 * Display search form and jobs found during user search.
	 */
	public function display_search_results_action() {
		$do_search = (int)$_GET['page_number'];

		$db = $this->_general_env->get_db();
		$domain = $this->_global_environment->get_domain();
		$lang = $this->_global_environment->get_general_language();
		$employer = $this->_global_environment->get_employer_environment()->get_user();
		$session = $this->_general_env->get_session();

		$form = new Flexible_job_search_form($this->_general_env->get_session(), (new Common_options_appender($db))->set_lang($lang), $lang, $this->_ip_country);
		$form->init_preserved_fields();
		$form->preserve_all_values();
		if ($do_search && $this->_ip_country && $this->_ip_country->get_id() == Country::USA) {
			$state_searcher = State::get_searcher(new Db_searcher($db));
			$state_searcher->set_country_search($this->_ip_country);
			$states = $state_searcher->search(1, 50, ['name']);
		}

		if ($this->_global_environment->get_jobseeker_environment()->get_session()->get_value('apply_success_msg')) {
			$form->add_success_message($this->_global_environment->get_jobseeker_environment()->get_session()->get_value('apply_success_msg'));
			$this->_global_environment->get_jobseeker_environment()->get_session()->set_value('apply_success_msg', null);
		}

		if (!$this->_global_environment->get_admin_environment()->get_user()) {
		}
		$fields = $form->get_fields();

		$options_manager = new Options_manager($db);
		$o = $options_manager->get_options(array('rows_job_search', 'max_job_search_results'));

		$valid = $form->validate();

		if ($do_search && $valid && $_GET['page_number'] * $o['rows_job_search'] <= $o['max_job_search_results']) {
			require_once SPHINX_PATH.'sphinxapi.php';
			$sphinx_client = new L4g_sphinx_client();
			$sphinx_client->SetServer(SPHINX_SEARCH_HOST, SPHINX_SEARCH_PORT);
			$sphinx_client->add_backup_server(SPHINX_SEARCH_BACKUP_HOST, SPHINX_SEARCH_BACKUP_PORT);
			$list_searcher = new Search_results_job_list_searcher(
				$form->create_searcher($db, clone $sphinx_client, $this->_get_jobseeker_country(), $states, $processed_kw), $domain, $lang
			);
			$unformatted_jobs = $list_searcher->find_jobs(
				$_GET['page_number'],
				$o['rows_job_search'],
				//@todo 'd' is being deprecated, replaced by SRO;
				//if we have keywords, and are not comming from notifications, sort by search match weight
				//otherwise sort by date
				$processed_kw && (!$_GET['d'] && $_GET[self::SRO_PARAM] != self::SRO_SEARCH)
					? []
					: [Job_list_searcher::ORDER_CREATION_DATE => Searcher::ORDER_DESC]
			);
			$had_searched = $session->get_value('had_searched');
			$session->set_value('had_searched', true);
			if ($this->_is_bot && $_POST) {
				trigger_error("TMP LOG: search done by what was detected as bot!");
			}
		}

		if ($unformatted_jobs) {
			$formatter_builder = new Job_list_formatter_builder(
				$this->_global_environment, $this->_url_manager, $this->_global_environment->get_cache_storage()
			);
			$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(null, false), Formatted_job_list::LOCATION_LEVEL_COUNTRY);
			$formatted_jobs = $formatted_job_list->format_jobs($unformatted_jobs, $lang, $this->_get_ip_country(), ['subcategories']);

			$total_job_count = $list_searcher->count_total_jobs();

			$paginator = new Paginator(min($total_job_count, $o['max_job_search_results']), $o['rows_job_search'], 10, $_GET['page_number']);
			$paginator_formatter = new Simple_paginator_formatter($paginator, $this->_url_manager);
			$pages = $paginator_formatter->format_paginator('job_list', 'display_search_results', array());
			$first_page_url = $this->_url_manager->get_url('job_list', 'display_search_results', array('page_number' => 1));
			$pages = $this->_set_first_page_link($pages, $first_page_url, $_GET['page_number']);

		}
		else {
			$total_job_count = 0;
		}
		$section = $this->_setup_site_section();
		if ($do_search && !$this->_global_environment->get_admin_environment()->get_user()) {
			if ($fields['country_id']->get_value()) {
				$country = 'in '.(new Country($db, $fields['country_id']->get_value()))->get_name($lang);
			}
			if ($fields['city_id']->get_value()) {
				$city = new City($db, $fields['city_id']->get_value());
				$city->init(['name']);
				$city = 'city:'.$city->get_name();
			}
			$origin = $this->_general_env->get_session()->get_value('search_origin') ?: 'rs_';
			$this->_general_env->get_session()->set_value('search_origin', null);
			$log_item = ("searched____").($had_searched ? '+' : '!').($section->is_mobile_user_agent ? 'm' : 'd')." $origin";
			file_put_contents(
				TMP_PATH.'/logs/new_search_tracking.txt',
				date('Y-m-d H:i:s ')."$log_item found:$total_job_count (on page: {$_GET['page_number']}) for '$processed_kw' $country $city\n",
				FILE_APPEND
			);
		}

		$afs_manager = new Afs_display_manager($this->_get_geoip_country(), $form->get_afs_query($db, $lang));
		$section->is_search = true;
		$section->has_results = (bool)$formatted_jobs;
		$view = $this->_get_view($formatted_jobs, $pages, null, true, $section, $afs_manager, !$do_search);

		if ($formatted_jobs) {
			Job::bulk_init($db, $unformatted_jobs, ['description', 'skills', 'benefits']);
			$view->excerpts = [];
			$num_formatted = count($formatted_jobs);
			$j = 0;
			foreach ($unformatted_jobs as $job) {
				for ($j; $j < $num_formatted; $j++) {
					if ($formatted_jobs[$j]['id'] == $job->get_id()) {
						$cats = [];
						if ($formatted_jobs[$j]['subcategories']) {
							foreach ($formatted_jobs[$j]['categories'] as $i => $cat) {
								$cats[] = $cat.($formatted_jobs[$j]['subcategories'][$i] ? ' (<i>'.implode('</i>, <i>', $formatted_jobs[$j]['subcategories'][$i]).'</i>)' : '');
							}
						}
						$cats = implode(', ', $cats ?: $formatted_jobs[$j]['categories']);

						break;
					}
				}
				$view->excerpts['desc'][] = $job->get_description().' '.$job->get_skills().' '.$job->get_benefits();
				$view->excerpts['loc'][] = $formatted_jobs[$j]['location'];
				$view->excerpts['title'][] = $formatted_jobs[$j]['title'];
				$view->excerpts['cat'][] = $cats;
				$view->excerpts['employer'][] = $formatted_jobs[$j]['employer'];
			}
			// note that we don't need to use jobs_flexible_delta or jobs_flexible_newest here, as the only thing the index is used for is
			// picking up the charset_table
			list(
				$view->excerpts['desc'],
				$view->excerpts['loc'],
				$view->excerpts['title'],
				$view->excerpts['cat'],
				$view->excerpts['employer'],
			) = array_chunk((array)$sphinx_client->BuildExcerpts(array_merge(
				$view->excerpts['desc'],
				$view->excerpts['loc'],
				$view->excerpts['title'],
				$view->excerpts['cat'],
				$view->excerpts['employer']
			), 'jobs_flexible', $processed_kw, ['around' => 9, 'limit' => 300]), count($formatted_jobs));
		}
		$view->jobs_heading = $lang->get_text('FLEXIBLE_SEARCH_RESULTS_HEADING');

		$view->set_css('flexible_job_search_adv.css');
		$view->set_include('spinner', 'spinner.php');

		if ((!($range = Security_guard::get_current_range()) || !$range->is_good_crawler)) {
			Trip_wire::enable_trip_wire();
		}
		else if ($fields['present_country_only']->get_value() && $sphinx_client) {
			if ($unformatted_jobs || (new Search_results_job_list_searcher($form->create_searcher($db, $sphinx_client), $domain, $lang))->find_jobs(1, 1)) {
				$view->search_accept_all_msg = $lang->get_text('JOB_SEARCH_ACCEPT_ALL_SEARCH_MSG');
			}
		}
		$view->is_search = true;
		$jobseeker = $this->_global_environment->get_jobseeker_environment()->get_user();
		if ($user = $employer ?: $jobseeker) {
			$user->init(['country_id']);
			if (in_array($user->get_location()->get_country()->get_id(), Cv::get_eu_country_ids())) {
				$view->show_eu_option = true;
			}
		}
		if (empty($unformatted_jobs) && $do_search) {
			if (is_null($employer) && is_null($jobseeker)) {
				$reg_link = $this->_ip_country && $this->_ip_country->get_id() == Country::USA && $this->_ip_state
					? $this->_url_manager->get_url('jobseeker_info', 'registration_form_state', [
						'state_short_name' => $this->_ip_state->get_url_name(true)
					])
					: $this->_url_manager->get_url('jobseeker_info', 'registration_form');
				$view->no_results_msg = str_replace(
					['{registration_url}', '{login_url}'],
					[$reg_link, $this->_url_manager->get_url('authorization', 'display_login_form')],
					$lang->get_text('NO_SEARCH_RESULTS_NO_USER')
				);
			}
			else {
				if ($jobseeker) {
					$job_match_filter_searcher = Job_match_filter::get_searcher(new Db_searcher($db));
					$job_match_filter_searcher->set_jobseeker_search($jobseeker);
					$job_match_filter_searcher->set_is_enabled_search(true);
					$total_filters = $job_match_filter_searcher->count();
				}
				if (!$total_filters && $jobseeker) {
					$view->no_results_msg = str_replace(
						'{job_match_url}',
						$this->_url_manager->get_url('job_match_filter', 'display'),
						$lang->get_text('NO_SEARCH_RESULTS_NO_MATCHLIST')
					);
					$job_match_filter_form = new Job_match_filter_form(
						$this->_global_environment->get_jobseeker_environment()->get_session(), $domain, new Common_options_appender($db)
					);
					$form->prepopulate_job_match_filter_form($job_match_filter_form);
					$job_match_filter_form->preserve_all_values();
				}
				else if ($valid) {
					$view->no_results_msg = $lang->get_text('NO_SEARCH_RESULTS');
				}
				else {
					$view->no_results_msg = str_replace(
						array('{field}', '{length}'),
						array($lang->get_text('JOB_SEARCH_KEYWORDS'), Flexible_job_search_form::KEYWORDS_MAX_LENGTH),
						$lang->get_text('ERR_KEYWORD_SEARCH_TOO_LONG')
					);
				}
			}
		}
		else if (!$do_search) {
			$jobs_table_page_list = new Jobs_table_page_list($this->_general_env->get_db(), $this->_url_manager, $lang);
			$jobs_table_link_widget = new Jobs_table_page_list_widget($jobs_table_page_list, $lang);
			$view->set_jobs_table_pages($jobs_table_link_widget, $this->_url_manager->get_url('job_category_list', 'list_job_all'));
		}
		if ($view->is_admin) {
			$view->set_js('notifications.js');
			$view->weights = [];
			foreach ((array)$unformatted_jobs as $job) {
				$view->weights[$job->get_id()] = $job->get_search_result_weight();
			}
		}
		else {
			$view->set_js('push_app.js');
		}

		$current_page = $this->_get_current_site_page();
		if (!is_null($current_page)) {
			$view = $this->_set_site_page_meta($view, $current_page);
		}
		$view->start_nr = ($_GET['page_number'] - 1) * $o['rows_job_search'] + 1;

		$view->set_css('old_forms.css');
		$view->set_include('search_form', 'flexible_job_search.php');
		$view->set_js('search.js');
		$view->set_js('tag_sel.js');
		$view->set_js('slider.js');
		$view->form_hash = $form->hash();
		if ($jobseeker) {
			$sub_searcher = Info_subscription::get_searcher(new Db_searcher($db));
			$sub_searcher->set_jobseeker_search($jobseeker);
			$sub_searcher->set_subject_search(Info_subscription::SUBJ_NEW_JOBS);
			$sub_searcher->set_via_email_search(true);
			$sub_searcher->set_recipient_type_search(Info_subscription::RECIPIENT_JOBSEEKER);
			$view->new_jobs_subscriptions = array_map(
				function (Info_subscription $s) use ($db) {
					$data = json_decode($s->data, true);
					return [
						'id' => $s->get_id(),
						'form_data' => $s->data,
						//frontend has most names in search form itself and thus it should use it
						//but since state and city are dynamically loaded, it is at least for now simpler to pass them
						//from server side
						'state' => $data['state_id'] ? (new State($db, $data['state_id']))->fluent_init()->get_short_name() : '',
						'city' => $data['city_id'] ? (new City($db, $data['city_id']))->fluent_init()->get_name() : '',
					];
				},
				$sub_searcher->search(0, 0, null)
			);
			$view->subscription_urls = [
				'view_template' => $this->_url_manager->get_url('info_subscriptions', 'notification_activate', ['subscription' => '{id}']),
				'remove_template' => $this->_url_manager->get_url('info_subscriptions', 'subscription_remove', ['subscription' => '{id}']),
				'subscribe' => $this->_url_manager->get_url('info_subscriptions', 'subscribe'),
			];
		}

		$view->subscribe_url = $this->_url_manager->get_url('job_match_list', 'push_subscribe');
		$view->endpoint_url = $this->_url_manager->get_url('info_subscriptions', 'save_endpoint');
		$view->set_include('push_info_box', 'push_info_box.php');

		foreach (Country::get_all($db, ['currency_id']) as $c) {
			$view->country_currencies[$c->get_id()] = $c->get_currency()->get_id();
		}

		$view->form_action = $this->_url_manager->get_url('job_search', 'flexible_search');
		$view->form = new Location_form_decorator(
			$form,
			$db,
			$this->_url_manager->get_url('location_list', 'load_states'),
			$this->_url_manager->get_url('location_list', 'load_cities')
		);
		$view->form_helper = new Form_view_helper($form);

		$view->total_item_count = $total_job_count;
		$view->display();
		$form->clear_success_messages();
	}

	/**
	 * @return Country|null
	 */
	private function _get_jobseeker_country() {
		$jobseeker = $this->_global_environment->get_jobseeker_environment()->get_user();
		if (!is_null($jobseeker)) {
			try {
				$jobseeker->init(array('country_id'));
			}
			catch (Not_existing_db_model_exception $e) {
				return $this->_geoip->get_ip_country($this->_general_env->get_db(), $_SERVER['REMOTE_ADDR']);
			}
			return $jobseeker->get_location()->get_country();
		}
		return $this->_geoip->get_ip_country($this->_general_env->get_db(), $_SERVER['REMOTE_ADDR']);
	}

	/**
	 * @todo move to Employer_formatter
	 * @param Employer $employer
	 * @param array $jobs
	 * @return array
	 */
	private function _get_formatted_employer(Employer $employer, array $jobs) {
		$lang = $this->_global_environment->get_general_language();

		$employer_formatter = new Employer_formatter();
		$formatted_employer = $employer_formatter->format_html($employer, $lang);

		//move values to 'value' keys
		$view_formatted_employer = array();
		foreach ($formatted_employer as $key => $value) {
			$view_formatted_employer[$key]['value'] = $value;
		}

		if (!empty($formatted_employer['website']['value'])) {
			$view_formatted_employer['website_link'] = $this->_url_manager->get_url(
				'website_click', 'click', array('employer_id' => $employer->get_id())
			);
		}
		sort($view_formatted_employer['job_categories']['value']);
		$view_formatted_employer['job_categories']['value'] = implode('; ', $view_formatted_employer['job_categories']['value']);

		//logo
		try {
			$logo = $employer->get_logo();
		}
		catch (Exception $e) { //handle not existing files
			$view_formatted_employer['logo_path']['value'] = '';
		}
		if (!is_null($logo)) {
			$view_formatted_employer['logo_path']['value'] = File_system_helper::get_path_www($logo->get_path(), CDN_HOST);
			$first_job_location = $jobs[0] ? $jobs[0]->get_location() : null;
			$alt_vars = [
				'/{employer_name}/' => $view_formatted_employer['name']['value'],
				'/{first_job_title}(,?)/' => $jobs[0] ? $jobs[0]->get_title().'\1' : '',
				'/{first_job_city}(,?)/' =>
					$first_job_location && $first_job_location->get_city() ? $first_job_location->get_city()->get_name().'\1' : '',
				'/{first_job_state}(,?)/' =>
					$first_job_location && $first_job_location->get_state() ? $first_job_location->get_state()->get_name().'\1' : '',
				'/{first_job_country}(,?)/' => $first_job_location ? $first_job_location->get_country()->get_name($lang).'\1' : '',
			];
			$view_formatted_employer['logo_alt']['value'] = trim(preg_replace(
				array_keys($alt_vars), array_values($alt_vars), $lang->get_text('EMPLOYER_LOGO_ALT')));
			$view_formatted_employer['logo_alt']['value'] = preg_replace('~ in$~', '', $view_formatted_employer['logo_alt']['value']);
		}

		if ($employer->get_hide_location()) {
			unset($view_formatted_employer['address']);
			unset($view_formatted_employer['postal_code']);
			unset($view_formatted_employer['city']);
			unset($view_formatted_employer['state']);
			unset($view_formatted_employer['country']);
		}

		$phone = $employer->get_phone();
		if (!empty($phone)) {
			$view_formatted_employer['phone']['value'] = $lang->get_text('HIDE_EMPLOYER_NUMBER');
		}

		$view_formatted_employer['phone']['label'] = $lang->get_text('EMPLOYER_PHONE');
		$view_formatted_employer['country']['label'] = $lang->get_text('EMPLOYER_COUNTRY');
		$view_formatted_employer['state']['label'] = $lang->get_text('EMPLOYER_STATE');
		$view_formatted_employer['city']['label'] = $lang->get_text('EMPLOYER_CITY');
		$view_formatted_employer['postal_code']['label'] = $lang->get_text('EMPLOYER_POSTAL_CODE');
		$view_formatted_employer['address']['label'] = $lang->get_text('EMPLOYER_ADDRESS');
		$view_formatted_employer['name']['label'] = $lang->get_text('EMPLOYER_NAME');
		$view_formatted_employer['website']['label'] = $lang->get_text('EMPLOYER_WEBSITE');
		$view_formatted_employer['job_categories']['label'] = $lang->get_text('EMPLOYER_JOB_CATEGORIES');

		return $view_formatted_employer;
	}

	/**
	 * Common method for displaying all job list pages.
	 * @param int $page_number
	 * @param Job_list_page $job_list_page
	 * @param array $list_criteria
	 * @param string $loc_level One of Formatted_job_list constants
	 * @param Job_list_display_options $options
	 * @param Site_section $section
	 * @param array $custom_path custom path links if custom path is needed
	 * @return array|bool Array containing view object, job searcher and unformatted job objects on the current page
	 * false is returned if redirect was performed, array (view, job searcher, unformatted jobs) if view displaying should be performed.
	 * @internal we cannot move this method to another class, because it heavily relies on controller data and methods.
	 * @todo use this method in all job list actions
	 */
	private function _display_page($page_number, Job_list_page $job_list_page, array $list_criteria, $loc_level, Job_list_display_options $options, Site_section $section, array $custom_path = []) {
		if ((!($range = Security_guard::get_current_range()) || !$range->is_good_crawler)) {
			Trip_wire::enable_trip_wire();
		}
		list($db, $lang, , $domain, $user_logged_in, $opt_man) = $this->_get_common();
		$cache = $this->_global_environment->get_cache_storage();

		$action = $options->action ?: $this->_action;
		$opt = $options->job_list_options ?: $this->_get_all_job_list_options($action, $page_number);

		if ($opt['max_page'] < $page_number) {
			$this->_redirect($job_list_page->get_url($this->_url_manager, 1));
			return false;
		}
		if ($opt['fix_url'] && Url_fixer::fix_url($job_list_page, $this->_url_manager)) {
			return false;
		}

		$latest_job = new Latest_job_manager($db, $cache);
		$list_criteria = $options->include_all_languages ? $list_criteria : array_merge([$lang], $list_criteria);
		require_once SPHINX_PATH.'sphinxapi.php';
		$sphinx_client = new L4g_sphinx_client();
		$sphinx_client->SetServer(SPHINX_SEARCH_HOST, Jobs_app::get_test_mode() ? SPHINX_SEARCH_TEST_PORT : SPHINX_SEARCH_PORT);
		$sphinx_client->add_backup_server(SPHINX_SEARCH_BACKUP_HOST, SPHINX_SEARCH_BACKUP_PORT);

		$job_searcher = new Sphinx_job_searcher(new Sphinx_db_searcher($sphinx_client), $db, null);
		$job_list_searcher = new Sphinx_job_list_searcher($job_searcher, $domain, $list_criteria);

		$unformatted_jobs = $job_list_searcher->find_jobs(
			$page_number,
			$page_number == 1 ? $opt['num_first_page_jobs'] : $opt['jobs_per_page'],
			[Job_list_searcher::ORDER_CREATION_DATE => Searcher::ORDER_DESC],
			$options->job_shift + ($page_number == 1 ? 0 : ($opt['num_first_page_jobs'] - $opt['jobs_per_page'])),
			['title', 'skills']
		);

		$formatter_builder = new Job_list_formatter_builder($this->_global_environment, $this->_url_manager, $cache);
		$list_formatter = $formatter_builder->build_job_list_formatter($opt['short_desc_len']);
		$formatted_job_list = new Formatted_job_list($list_formatter, $loc_level);

		if ($unformatted_jobs) {
			Job::bulk_init($db, $unformatted_jobs, ['title']);//for meta
			if ($options->under_location_url) {
				$list_formatter->set_under_location_url($options->under_location_url);
			}
			$formatted_jobs = $formatted_job_list->format_jobs($unformatted_jobs, $lang, $this->_get_ip_country());
			if ($page_number == 1 && $opt['allow_last_job'] && $formatted_jobs) {
				$latest_job->save($_SERVER['REQUEST_URI'], $formatted_jobs[0], $unformatted_jobs[0]->get_job_categories(), $lang);
			}
		}

		if (!$formatted_jobs) {
			if ($page_number == 1 && $opt['allow_last_job']) {
				$last_formatted_job = $latest_job->retrieve($_SERVER['REQUEST_URI']);
				unset($last_formatted_job['creation_date']);
			}
			if (!$last_formatted_job) {
				if ($opt['allow_no_jobs']) {
					return [
						$this->_setup_view(
							$this->_get_view(null, null, $section->country),
							$section,
							$job_list_page->get_meta_vars($section, $lang, [], $top_cities ?: []),
							$action,
							$custom_path,
							$options->meta_page_number_params ?: $opt['meta_pg_nr_params']
						),
						$job_searcher,
						[]
					];
				}
				throw new Page_not_found_exception($_SERVER['REQUEST_URI'], $lang->get_text('NOT_FOUND_JOB_LIST'));
			}

			unset($last_formatted_job['employer']);
			$formatted_jobs = [$last_formatted_job];
		}

		if (count($unformatted_jobs) < ($page_number == 1 ? $opt['num_first_page_jobs'] : $opt['jobs_per_page'])) {
			$total_job_count = $page_number == 1 ? count($unformatted_jobs)
				: (($page_number - 2) * $opt['jobs_per_page'] + $opt['num_first_page_jobs'] + count($unformatted_jobs));
		}
		else {
			$total_job_count = $job_list_searcher->count_total_jobs($this->_global_environment->get_cache_storage());
		}

		$pages = $this->_get_pages(
			$page_number,
			$total_job_count,
			$opt['jobs_per_page'],
			$opt['max_page'],
			$job_list_page,
			$options->job_shift + $opt['num_first_page_jobs'] - $opt['jobs_per_page']
		);

		$view = $this->_get_view($formatted_jobs, $pages, $section->country, $opt['display_footer'], $section, $opt['afs_manager']);
		if (!$unformatted_jobs) {
			$view->deleted_job_message = $latest_job->get_list_message(
				$last_formatted_job, $list_criteria, $this->_url_manager->get_url('job_list', 'display_search_form'), $lang
			);
		}

		if ($opt['display_search_link'] && !$options->disable_search_link) {
			$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');
		}

		if ($page_number == 1 && $opt['display_top_jobs']) {
			Top_job_table::assign_formatted_jobs(
				$this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), $list_criteria, $opt['num_first_page_jobs'], $formatted_jobs, $total_job_count
			);
		}

		if ($page_number == 1) {
			$this->_assign_comments($view, $section, $list_criteria);
		}
		if ($page_number > 1 && preg_match('#^(https?:)?//w{0,3}\.?'.$_SERVER['HTTP_HOST'].'#', $_SERVER['HTTP_REFERER'])) {
			$view->can_scroll_to_pagination = 1;
		}

		//since city job lists require more top cities, and sometimes take from neighbors, we do not overide that
		if (!($top_cities = $options->formatted_top_cities)) {
			$smallest_location = $section->county ?: ($section->state ?: ($section->country ?: ($section->region ?: null)));
			//Do not search for top cities it is generic usa list as that is super slow.
			if ($smallest_location && !($smallest_location instanceof Country && $smallest_location->get_id() == Country::USA)) {
				$top_city_list = new Top_job_city_list(
					$smallest_location,
					$db,
					$lang,
					$this->_get_container()->get_registered('SDB')
				);
				$top_cities = $top_city_list->get_formatted_cities($this->_url_manager, self::META_TOP_CITIES_COUNT, true);
			}
		}

		$view = $this->_setup_view(
			$view,
			$section,
			array_merge(
				$job_list_page->get_meta_vars($section, $lang, $unformatted_jobs, $top_cities ?: []),
				$this->_get_cat_sub_counts($section, $list_criteria, $total_job_count)
			),
			$action,
			$custom_path,
			$options->meta_page_number_params ?: $opt['meta_pg_nr_params']
		);

		if (!$options->hide_total) {
			$view->total_item_count = $total_job_count;
		}
		$view->start_nr = ($page_number - 1) * $opt['jobs_per_page'] + 1;

		return [$view, $job_searcher, $unformatted_jobs];
	}

	/**
	 * Display country job list accepting applications from specific country
	 */
	public function display_country_for_country_action() {
		$this->_display_country_for_country(1);
	}
	/**
	 * Display country job list accepting applications from specific country
	 */
	public function display_country_for_country_page_action() {
		$this->_display_country_for_country($_GET['page_number']);
	}

	/**
	 * @param int $page_number
	 */
	private function _display_country_for_country($page_number) {
		$section = $this->_setup_site_section();
		list($db, $lang, , $domain, $user_logged_in, $opt_man) = $this->_get_common();

		if (!isset($_GET['origin_country_url_name']) || strlen($_GET['origin_country_url_name']) > 100) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		$searcher = Country::get_searcher(new Db_searcher($db));
		$searcher->set_url_name_search($_GET['origin_country_url_name'], $lang, true);
		list($origin_country) = $searcher->search(1, 1);
		if (!$origin_country) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		$origin_country->init(null, self::INIT_CACHE_SECONDS);
		$destinations = $origin_country->get_has_citizen_job_lists_in($db);
		if (!in_array($section->country->get_id(), Country::ids($destinations))) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$job_list_page = new Job_list_page('display_country_for_country', $section);
		$job_list_page->set_custom_url_params(['origin_country_url_name' => $origin_country->get_url_name($lang, true)]);
		$options = new Job_list_display_options();
		$options->action = 'display_country_for_country';

		$action = $options->action ?: $this->_action;
		$opt = $options->job_list_options ?: $this->_get_all_job_list_options($action, $page_number);

		if ($opt['max_page'] < $page_number) {
			$this->_redirect($job_list_page->get_url($this->_url_manager, 1));
			return false;
		}
		if ($opt['fix_url'] && Url_fixer::fix_url($job_list_page, $this->_url_manager)) {
			return false;
		}

		$form = new Flexible_job_search_form($this->_general_env->get_session());
		$fields = $form->get_fields();
		$fields['country_id']->set_value($section->country->get_id());

		require_once SPHINX_PATH.'sphinxapi.php';
		$sphinx_client = new L4g_sphinx_client();
		$sphinx_client->SetServer(SPHINX_SEARCH_HOST, SPHINX_SEARCH_PORT);
		$sphinx_client->add_backup_server(SPHINX_SEARCH_BACKUP_HOST, SPHINX_SEARCH_BACKUP_PORT);
		$list_searcher = new Search_results_job_list_searcher($form->create_searcher($db, $sphinx_client, $origin_country), $domain, $lang);

		if ($unformatted_jobs = $list_searcher->find_jobs($page_number, $opt['jobs_per_page'])) {
			$formatted_jobs = (new Formatted_job_list(
					(new Job_list_formatter_builder($this->_global_environment, $this->_url_manager))->build_job_list_formatter($opt['short_desc_len']),
					Formatted_job_list::LOCATION_LEVEL_COUNTRY
				))->format_jobs($unformatted_jobs, $lang, $this->_get_ip_country());

			if ($page_number == 1) {
				(new Latest_job_manager($db))->save($_SERVER['REQUEST_URI'], $formatted_jobs[0], $unformatted_jobs[0]->get_job_categories(), $lang);
			}
			$total = $list_searcher->count_total_jobs();
		}
		else {
			if ($page_number == 1) {
				$last_formatted_job = (new Latest_job_manager($db))->retrieve($_SERVER['REQUEST_URI']);
				unset($last_formatted_job['creation_date'], $last_formatted_job['employer']);
				$formatted_jobs = [$last_formatted_job];//check or filter?
				if (!$last_formatted_job) {
					trigger_error("Requested to display country for country list with no jobs and no last job present.");
					//XXX do something truly special!
				}
			}
			else {
				throw new Page_not_found_exception($_SERVER['REQUEST_URI'], $lang->get_text('NOT_FOUND_JOB_LIST'));
			}
		}

		$pages = $this->_get_pages(
			$page_number, $total, $opt['jobs_per_page'], $opt['max_page'], $job_list_page, $opt['num_first_page_jobs'] - $opt['jobs_per_page']
		);

		$view = $this->_setup_view(
			$this->_get_view($formatted_jobs, $pages, $section->country, $opt['display_footer'], $section, $opt['afs_manager']),
			$section,
			array_merge(
				$job_list_page->get_meta_vars($section, $lang, $unformatted_jobs, $top_cities ?: []),
				['{citizen_country}' => $origin_country->get_name($lang)]
			),
			$action,
			[
				$this->_url_manager->get_url('country_list', 'list_job_all'),
				$this->_url_manager->get_url('country_list', 'list_job_for_country_citizens', ['country_short_name' => $_GET['origin_country_url_name']]),
				$this->_url_manager->get_url('job_list', 'display_country_for_country', ['country_short_name' => $_GET['country_short_name'], 'origin_country_url_name' => $_GET['origin_country_url_name']]),
			],
			$options->meta_page_number_params ?: $opt['meta_pg_nr_params']
		);

		$view->total_item_count = (int)$total;
		$view->start_nr = ($page_number - 1) * $opt['jobs_per_page'] + 1;
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');
		$view->can_scroll_to_pagination = $page_number > 1 && preg_match('#^(https?:)?//w{0,3}\.?'.$_SERVER['HTTP_HOST'].'#', $_SERVER['HTTP_REFERER']);
		//XXX top jobs? as in _display_page
		$view->display();
	}

	/**
	 * @param Job_list_section $list_section
	 * @param array $criteria job list criteria
	 * @param Registered_user|null $user
	 * @return array [can_comment]
	 */
	private function _can_comment(Job_list_section $list_section, array $criteria, Registered_user $user = null) {
		$db = $this->_general_env->get_db();
		$comment_on = $this->_general_env->get_session()->get_value('comment_on');
		if (in_array($list_section->get_id(), (array)$comment_on['yes'])) {
			return [true];
		}
		else if (in_array($list_section->get_id(), (array)$comment_on['no'])) {
			return [false];
		}

		$can_comment = $user && Comment_countries_manager::can_comment($db, $user, $criteria);
		$comment_on[$can_comment ? 'yes' : 'no'] = $list_section->get_id();
		$this->_general_env->get_session()->set_value('comment_on', $comment_on);
		return [$can_comment];
	}

	/**
	 * @param Html_view $view
	 * @param Site_section $section
	 * @param array $criteria job list search criteria
	 */
	private function _assign_comments(Html_view $view, Site_section $section, array $criteria) {
		if (!Comment_countries_manager::COMMENTS_ENABLED) {
			return;
		}
		list($db, $lang, $default_lang, , ) = $this->_get_common();
		if ($lang->get_id() != $default_lang->get_id()) {
			return;
		}
		$user = $this->_global_environment->get_employer_environment()->get_user()
			?: $this->_global_environment->get_jobseeker_environment()->get_user();
		if ($user) {
			$user->init(['country_id']);
		}

		$list_section = Job_list_section::load_or_create($db, array_merge([$lang], $criteria));
		list($can_comment) = $this->_can_comment($list_section, $criteria, $user);

		$ip_country = $this->_geoip->get_ip_country($db, $_SERVER['REMOTE_ADDR']);
		if ($ip_country && Comment_countries_manager::can_country_comment($db, $ip_country, $criteria)) {
			$view->comments_intro = Comment_intro_manager::get($lang, $section);
		}
		$view->comments = Comment_formatter::format_comments(Comment::get_searcher(new Db_searcher($db)), $list_section, $this->_url_manager);
		$view->can_comment = $can_comment;

		$view->set_include('job_list_comments', 'job_list_comments.php');

		$view->is_admin = (bool)$this->_global_environment->get_admin_environment()->get_user();

		if ($user) {
			$view->vote_url = $this->_url_manager->get_url('comment', 'vote', ['comment_id' => '{cid}', 'up' => '{up}']);
			$view->current_voter = get_class($user).$user->get_id();
			$view->upvote_title = $lang->get_text('COMMENT_UPVOTE');
			$view->downvote_title = $lang->get_text('COMMENT_DOWNVOTE');
			$view->votes = Comment::get_user_votes($db, $user, $list_section);
		}
		if ($view->is_admin) {
			$view->set_js('comment_editing.js');
			$view->editing_url = $this->_url_manager->get_url('comment', 'edit');
			$view->deletion_url = $this->_url_manager->get_url('comment', 'delete', ['comment_id' => '{cid}']);
			$view->confirming_del = $this->_global_environment->get_admin_environment()->get_session()->get_value('deleting_comment');
			$this->_global_environment->get_admin_environment()->get_session()->set_value('deleting_comment', null);

			//we search again because template is (include) cached and we do not want to store ips there as they would be publicly visible.
			$searcher = Comment::get_searcher(new Db_searcher($db));
			$searcher->set_job_list_section_search($list_section);
			$comments = $searcher->search(0, 0, ['ip']);
			$view->ips = [];
			foreach ($comments as $c) {
				$view->ips[$c->get_id()] = [$c->ip];
			}
			$view->ban_ip_url = $this->_url_manager->get_url('comment', 'ban_ip', ['cid' => '{cid}']);
		}

		if ($can_comment) {
			$view->commenting_url = $this->_url_manager->get_url('comment', 'post', ['section' => $list_section->get_id()]);
			$view->max_com_len = (new Options_manager($db))->get_option('comment_max_length');
			$view->comment_form = new Comment_form($this->_general_env->get_session(), $view->max_com_len, $user);
			Form_labeler::label_fields($view->comment_form, array_map([$lang, 'get_text'], [
				'link_to_profile' => 'COMMENTS_LINK_TO_JOB_LIST', 'poster_name' => 'COMMENTS_POSTER_NAME_LABEL', 'text' => 'COMMENTS_TEXT_LABEL',
			]));
			if ($user) {
				$user->init(['name']);
				$view->comment_form->get_fields()['poster_name']->set_value($user->get_name());
			}
			$view->comment_form->init_preserved_fields();
			if ($errors = $view->comment_form->get_errors()) {
				$err_txt_map = [
					Comment_form::ERROR_MIN_INTERVAL => 'COMMENTS_MIN_INTERVAL_ERROR',
					Comment_form::ERROR_MAX_LENGTH => 'COMMENTS_MAX_LEN_ERR',
					Data_form::ERROR_EMPTY => 'COMMENTS_NAME_FIELD_EMPTY'
				];
				$view->comment_error = $lang->get_text($err_txt_map[array_values($errors)[0]]);
			}
			$view->comment_form->clear_errors();
			$view->comments_disabled = !$user;
		}

		$view->set_include('job_list_comments_logged_in', 'job_list_comments_logged_in.php');
	}

	/**
	 * @param string $action
	 * @param int $page_number
	 * @return array
	 */
	private function _get_all_job_list_options($action, $page_number) {
		list(, $lang, , , , $opt_man) = $this->_get_common();
		$job_list_options = new Job_list_options($opt_man);
		return $job_list_options->get_options($action, $lang, $page_number);
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if employer does not exists, has no jobs, or belongs to other or unassigned domain
	 */
	private function _display_employer_page($page_number) {
		list($db, $lang, , $domain, ) = $this->_get_common();

		$employer = new Employer($db, $_GET['employer_id']);
		try {
			$employer->init();
		}
		catch (Not_existing_db_model_exception $e) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		//check if domain is correct
		$employer_domain = $employer->get_domain();
		if (empty($employer_domain)) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		if ($employer_domain->get_id() != $domain->get_id() || $employer->get_is_suspended()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$job_list_page = new Employer_job_list_page($lang, $employer);
		$options = new Job_list_display_options();
		$options->action = 'display_employer';
		$options->include_all_languages = true;
		$options->hide_total = true;
		$section = $this->_setup_site_section();
		$section->is_employer_job_list = true;
		if ($employer->get_location()->get_country()->get_id() == Country::USA) {
			$section->country = $employer->get_location()->get_country();
		}
		else {
			$section->country = null;
		}
		$result = $this->_display_page(
			$page_number,
			$job_list_page,
			[$employer, Static_job_list_searcher::CRITERIA_SHOW_NOLIST],
			Formatted_job_list::LOCATION_LEVEL_COUNTRY,
			$options,
			$section
		);

		if (!$result) {
			return;
		}

		$section->is_paying = $employer->get_job_plan()->is_paid();

		list($view, , $unformatted_jobs) = $result;

		$view->employer = $this->_get_formatted_employer($employer, $unformatted_jobs);

		if (!$unformatted_jobs) {
			$afb_var = $this->_get_banner_position_tpl_var_map()[Banner_pos::ABOVE_FOOTER];
			$afb_var2 = $this->_get_banner_position_tpl_var_map()[Banner_pos::ABOVE_FOOTER_2];
			unset($view->$afb_var, $view->$afb_var2);
		}

		$view->set_include('content', 'employer_page.php');
		$view->set_css('job_list.css');
		$view->set_css('old_forms.css');
		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if there is no jobs
	 */
	private function _display_all_page($page_number) {
		$section = $this->_setup_site_section();
		$job_list_page = new Job_list_page('display_all', $section);

		$options = new Job_list_display_options();
		$options->action = 'display_all';
		$result = $this->_display_page(
			$page_number, $job_list_page, array(), Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;
		if ($page_number == 1) {
			list($db, $lang, , $domain, ) = $this->_get_common();
			$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
				'all_job_category_list.php', date_create('tomorrow')->format('U') - date('U'), 'all_job_list_categories_'.$lang->get_id()
			);

			if (!$view->is_include_cached('all_job_category_list.php')) {
				$job_searcher = Job::get_searcher(new Db_searcher($db));
				$job_searcher->set_creation_date_search(new DateTime('-2 days'));
				$category_searcher = Job_category::get_searcher(new Db_searcher($db));
				$category_searcher->set_job_searcher(Static_job_list_searcher::init_mergable_searcher($job_searcher, $domain, [$lang]));

				$all_categories = $category_searcher->search();
				$formatted_categories = [];
				$category_link_template = $this->_url_manager->get_url(
					'job_list', 'display_category', ['job_category_url_name' => '<job_category_url_name>']
				);
				foreach ($all_categories as $job_category) {
					$category_link = str_replace('<job_category_url_name>', $job_category->get_url_name($lang), $category_link_template);
					$formatted_categories[] = ['name' => $job_category->get_name($lang), 'link' => $category_link];
				}

				asort($formatted_categories);
				$view->categories = $formatted_categories;
			}

			$view->set_include('all_job_category_list', 'all_job_category_list.php');
		}

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid category givent or there is not enough jobs to dispaly given page
	 */
	private function _display_category_page($page_number) {
		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_category', $section);
		$options = new Job_list_display_options();
		$options->action = 'display_category';
		$result = $this->_display_page(
			$page_number, $job_list_page, [$section->job_category], Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;

		if ($this->_general_env->get_session()->get_value('from_404_job')) {
			$this->_general_env->get_session()->set_value('from_404_job', false);
			$view->from_404_job_msg = $this->_global_environment->get_general_language()->get_text('JOB_LIST_FROM_404_JOB');
		}

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid category givent or there is not enough jobs to dispaly given page
	 */
	private function _display_subcategory_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_subcategory', $section);
		$options = new Job_list_display_options();
		$options->action = 'display_subcategory';
		$result = $this->_display_page(
			$page_number, $job_list_page, array($section->job_subcategory), Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_subcategory', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * Display first page of all online jobs
	 */
	public function display_online_action() {
		$this->_display_online_page_action(1);
	}

	/**
	 * Display page of all online jobs
	 */
	public function display_online_page_action() {
		$this->_display_online_page_action($_GET['page_number']);
	}

	/**
	 * @param int $page_number
	 */
	private function _display_online_page_action($page_number) {
		list($db, $lang, , $domain, ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_online', $section);

		$options = new Job_list_display_options();
		$options->action = 'display_online';
		$result = $this->_display_page(
			$page_number, $job_list_page, array(Static_job_list_searcher::CRITERIA_IS_ONLINE),
			Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $this->_setup_site_section()
		);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;

		$top_location_category_list_viewer = new Top_location_category_list_viewer($lang, $db, $this->_get_container()->get_registered('SDB'), $domain, $this->_url_manager);
		$top_location_category_list_viewer->assign_to_view($view, Static_job_list_searcher::CRITERIA_IS_ONLINE);

		$view->display();
	}

	/**
	 * Display frst page of online jobs of certain category
	 */
	public function display_online_category_action() {
		$this->_display_online_category_page_action(1);
	}

	/**
	 * Display page of online jobs of certain category
	 */
	public function display_online_category_page_action() {
		$this->_display_online_category_page_action($_GET['page_number']);
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid category givent or there is not enough jobs to dispaly given page
	 */
	private function _display_online_category_page_action($page_number) {
		list($db, $lang, , $domain, ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_online_category', $section);
		$options = new Job_list_display_options();
		$options->action = 'display_online_category';
		$result = $this->_display_page(
			$page_number, $job_list_page, array(Static_job_list_searcher::CRITERIA_IS_ONLINE, $section->job_category),
			Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section
		);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid country given or there is not enough jobs to display given page
	 */
	private function _display_country_page($page_number) {
		$section = $this->_setup_site_section();

		list($db, $lang, $default_lang, $domain, , ) = $this->_get_common();

		$location = new Location();
		$location->set_country($section->country);

		//custom page for custom path links
		$job_list_page = new Country_job_list_page($section->country, $section);

		$options = new Job_list_display_options();
		$options->action = 'display_country';
		$result = $this->_display_page(
			$page_number, $job_list_page, array($location), Formatted_job_list::LOCATION_LEVEL_COUNTRY,
			$options, $section, $job_list_page->get_path_links($this->_url_manager));

		if (!$result) {
			return;
		}

		list($view, $job_searcher, $unformatted_jobs) = $result;

		$top_location_category_list_viewer = new Top_location_category_list_viewer($lang, $db, $this->_get_container()->get_registered('SDB'), $domain, $this->_url_manager);
		$top_location_category_list_viewer->assign_to_view($view, $section->country);

		if ($lang->get_id() == $default_lang->get_id()) {
			if ($section->country->get_id() == Country::USA) {
				$view->state_list_link = $this->_url_manager->get_url('state_list', 'list_job_country',
					array('country_url_name' => $section->country->get_url_name($lang)));
				$view->state_list_link_caption = $lang->get_text('COUNTRY_JOB_LIST_STATE_LIST_LINK');

				$view->category_list_link = $this->_url_manager->get_url('job_category_list', 'list_job_all_country',
					array('country_url_name' => $section->country->get_url_name($lang)));
				$view->category_list_link_caption = $lang->get_text('JOB_LIST_CATEGORY_LIST_LINK');
			}
			if (in_array($section->country->get_id(), Country_part_time_job_list_page::get_enabled_countries_ids())) {
				$pt_searcher = clone $job_searcher;
				$pt_searcher->set_employment_type_search(new Employment_type($db, Employment_type::ID_PART_TIME));
				if (count($pt_searcher->search(1, 1)) > 0) {
					$view->under_pagination_link = $this->_url_manager->get_url('job_list', 'display_part_time_country',
						array('country_url_name' => $section->country->get_url_name($lang)));
					$view->under_pagination_link_caption = str_replace(
						'{country}', $section->country->get_name($lang), $lang->get_text('COUNTRY_PART_TIME_JOB_LIST_LINK')
					);
				}
			}
			if ($section->country->get_id() != Country::USA) {
				$formatter = new Job_city_list_formatter(
					Static_job_list_searcher::init_mergable_searcher(Job::get_searcher(new Db_searcher($db)), $domain, []),
					new Latest_job_manager($db, $this->_global_environment->get_cache_storage()),
					$this->_get_container()->get_registered('SDB'),
					[]
				);
				$formatter->set_job_count_filter(1);

				$c_searcher = City::get_searcher(new Db_searcher($db));
				$c_searcher->set_country_search($section->country);
				$c_searcher->set_is_important_search(true);

				$view->important_city_links = $formatter->format(
					$c_searcher->search(0, 0, ['name']),
					$this->_url_manager->get_url('job_list', 'display_important_city', [
						'country_short_name' => $section->country->get_url_name($lang, true), 'city_url_name' => '<city_url_name>'
					]),
					[],
					Job_location_list_formatter::ORDER_JOB_COUNT
				);
			}

		}

		$backfill_options = new Backfill_options(
		$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_country', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @throws Page_not_found_exception if state is not correctly specified or there is not enough jobs to display given page
	 */
	public function display_state_page_action() {
		$current_route = $this->_get_current_route();
		if (!is_null($current_route)) {
			$specifying_param = $current_route->get_specifying_param();
			if (!empty($specifying_param)) {
				$page_number = $current_route->get_specifying_param();
			}
		}
		if (empty($page_number) && !empty($_GET['page_number'])) {
			$page_number = $_GET['page_number'];
		}
		list($db, $lang, , $domain, , $opt_man) = $this->_get_common();

		$section = $this->_setup_site_section();

		//custom job list page for custom url handling
		$job_list_page = new State_job_list_page($lang, $section->state);

		$location = new Location();
		$location->set_state($section->state);

		$options = new Job_list_display_options();
		$options->under_location_url = City_job_list_page::get_job_activated_url($this->_url_manager, $section->state);
		$result = $this->_display_page(
			$page_number, $job_list_page, array($location), Formatted_job_list::LOCATION_LEVEL_STATE, $options, $section);

		if (!$result) {
			return;
		}

		list($view, $job_searcher, $unformatted_jobs) = $result;

		$top_location_category_list_viewer = new Top_location_category_list_viewer($lang, $db, $this->_get_container()->get_registered('SDB'), $domain, $this->_url_manager);
		$top_location_category_list_viewer->assign_to_view($view, $section->state);
		$top_location_subcategory_list_viewer = new Top_location_subcategory_list_viewer($lang, $db, $domain, $this->_url_manager);
		$top_location_subcategory_list_viewer->assign_to_view(
			$view, $opt_man->get_option('count_bottom_cat_subcat'), $section->state, 'TOP_LOC_CAT_SUBCAT'
		);

		if ($lang->get_id() == App_language::get_default_general_language($db)->get_id()) {
			$job_searcher->set_employment_type_search(new Employment_type($db, Employment_type::ID_PART_TIME));
			if (count($job_searcher->search(1, 1)) > 0) {
				$view->under_pagination_link = $this->_url_manager->get_url('job_list', 'display_part_time_state',
								array('state_id' => $section->state->get_id(), 'state_url_name' => $section->state->get_url_name()));
				$view->under_pagination_link_caption = str_replace(
					'{state}', $section->state->get_name(), $lang->get_text('STATE_PART_TIME_JOB_LIST_LINK')
				);
			}
		}

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_state_page', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->city_list_link = $this->_url_manager->get_url(
			'city_list', 'list_job_state', array('state_url_name' => $section->state->get_url_name(), 'state_id' => $section->state->get_id())
		);
		$view->city_list_link_caption = $this->_global_environment->get_general_language()->get_text('STATE_JOB_LIST_SEARCH_BY_CITY_LINK');

		$view->category_list_link = $this->_url_manager->get_url('job_category_list', 'list_job_all_state',
			array('state_url_name' => $section->state->get_url_name(), 'state_id' => $section->state->get_id()));
		$view->category_list_link_caption = $lang->get_text('JOB_LIST_CATEGORY_LIST_LINK');

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if request parameters are specified incorectly or there is not enough jobs to display given page
	 */
	private function _display_category_state_page($page_number) {
		list($db, $lang, , $domain, , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_category_state', $section);

		$location = new Location();
		$location->set_state($section->state);

		$options = new Job_list_display_options();
		$options->action = 'display_category_state';
		$options->under_location_url = new Job_activated_url($this->_url_manager->get_site_section_url(
			'job_list', 'display_category_city', $section));
		$result = $this->_display_page(
			$page_number, $job_list_page, array($location, $section->job_category), Formatted_job_list::LOCATION_LEVEL_STATE, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_category_state', $lang, $this->_global_environment->get_cache_storage()
		);
		$alt_backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_ALT, 'job_list', 'display_category_state', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options, $alt_backfill_options);

		$params = array(
			'state_short_name' => $section->state->get_url_name(true),
			'state_id' => $section->state->get_id(),
			'job_category_url_name' => $section->job_category->get_url_name($lang)
		);
		$view->city_list_link = $this->_url_manager->get_url('city_list', 'list_job_category_state', $params);
		$view->city_list_link_caption = $this->_global_environment->get_general_language()->get_text('STATE_JOB_LIST_SEARCH_BY_CITY_LINK');
		$view->display();
	}

	/**
	 * Action for redirecting old urls
	 * @throws Page_not_found_exception if city_id parameter is not recognized.
	 */
	public function display_city_page_old_action() {
		$current_route = $this->_get_current_route();
		if (!is_null($current_route)) {
			$specifying_param = $current_route->get_specifying_param();
			if (!empty($specifying_param)) {
				$page_number = $current_route->get_specifying_param();
			}
		}
		if (empty($page_number) && !empty($_GET['page_number'])) {
			$page_number = $_GET['page_number'];
		}

		list($db, , , , , ) = $this->_get_common();

		$current_city = new City($db, $_GET['city_id']);
		try {
			$current_city->init();
		}
		catch (Not_existing_db_model_exception $e) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		$current_state = $current_city->get_state();
		if (is_null($current_state)) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		try {
			$current_state->init(array('name', 'country_id'));
		}
		catch (Not_existing_db_model_exception $e) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$job_list_page = new City_job_list_page($current_city, new Site_section());

		$this->_redirect($job_list_page->get_url($this->_url_manager, $page_number));
	}

	/**
	 * @throws Page_not_found_exception if parameters are specified incorectly or there is not enough jobs to display given page
	 */
	public function display_city_page_action() {
		$current_route = $this->_get_current_route();
		if (!is_null($current_route)) {
			$specifying_param = $current_route->get_specifying_param();
			if (!empty($specifying_param)) {
				$page_number = $current_route->get_specifying_param();
			}
		}
		if (empty($page_number) && !empty($_GET['page_number'])) {
			$page_number = $_GET['page_number'];
		}

		list($db, $lang, , $domain, , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		//custom page for custom URL retrieval
		$job_list_page = new City_job_list_page($section->city, $section);

		$location = new Location();
		$location->set_city($section->city);
		$list_criteria = array($location);

		$job_list_options = $this->_get_all_job_list_options('display_part_time_city', $page_number);

		$job_count = $this->_calculate_job_count($job_list_options['jobs_per_page'], $list_criteria, $page_number);
		$top_city_count = $this->_get_top_city_count($job_count);
		list($top_cities, $top_cities_heading) = $this->_get_top_city_list($section->state, $section->city, $top_city_count);

		$options = new Job_list_display_options();
		$options->formatted_top_cities = $top_cities;
		$options->job_list_options = $job_list_options;
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_CITY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, $job_searcher, $unformatted_jobs) = $result;
		$view->top_cities_heading = $top_cities_heading;

		$top_location_category_list_viewer = new Top_location_category_list_viewer($lang, $db, $this->_get_container()->get_registered('SDB'), $domain, $this->_url_manager);
		$top_location_category_list_viewer->assign_to_view($view, $section->city, $section->city->get_name().", ".$section->state->get_short_name());

		if ($lang->get_id() == App_language::get_default_general_language($db)->get_id()) {
			$job_searcher->set_employment_type_search(new Employment_type($db, Employment_type::ID_PART_TIME));
			if (count($job_searcher->search(1, 1)) > 0) {
				$view->under_pagination_link = $this->_url_manager->get_url('job_list', 'display_part_time_city',
								array(
									'city_id' => $section->city->get_id(),
									'city_url_name' => $section->city->get_url_name(),
									'state_url_name' => $section->state->get_url_name()
								)
				);
				$view->under_pagination_link_caption = str_replace(
					'{city}', $section->city->get_name(), $lang->get_text('CITY_PART_TIME_JOB_LIST_LINK')
				);
			}
		}

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_city_page', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->cities = $top_cities;
		$view->set_include('top_cities', 'top_cities.php');
		$view->display();
	}

	/**
	 * Action for redirecting old urls
	 * @throws Page_not_found_exception if city_id parameter is not recognized.
	 */
	private function _display_category_city_page_old() {
		$section = $this->_setup_site_section();

		$this->_redirect($this->_url_manager->get_site_section_url('job_list', 'display_category_city', $section));

	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if parameters are specified incorectly or there is not enough jobs to display given page
	 */
	private function _display_category_city_page($page_number) {
		list($db, $lang, , $domain, , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_category_city', $section);

		$location = new Location();
		$location->set_city($section->city);

		$list_criteria = array($location, $section->job_category);

		$options = new Job_list_display_options();
		$options->action = 'display_category_city';
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_CITY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, $job_searcher, $unformatted_jobs) = $result;

		if ($lang->get_id() == App_language::get_default_general_language($db)->get_id()) {
			$job_searcher->set_employment_type_search(new Employment_type($db, Employment_type::ID_PART_TIME));
			if (count($job_searcher->search(1, 1)) > 0) {
				$view->under_pagination_link = $this->_url_manager->get_url('job_list', 'display_part_time_city',
								array(
									'city_id' => $section->city->get_id(),
									'city_url_name' => $section->city->get_url_name(),
									'state_url_name' => $section->state->get_url_name()
								)
				);
				$view->under_pagination_link_caption = str_replace(
					'{city}', $section->city->get_name(), $lang->get_text('CITY_PART_TIME_JOB_LIST_LINK')
				);
			}
		}

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_category_city', $lang, $this->_global_environment->get_cache_storage()
		);
		$alt_backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_ALT, 'job_list', 'display_category_city', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options, $alt_backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if parameters are specified incorectly or there is not enough jobs to display given page
	 */
	private function _display_subcategory_city_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_subcategory_city', $section);

		$location = new Location(array($section->city));

		$list_criteria = array($location, $section->job_subcategory);

		$options = new Job_list_display_options();
		$options->action = 'display_subcategory_city';
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_CITY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_subcategory_city', $lang, $this->_global_environment->get_cache_storage()
		);
		$alt_backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_ALT, 'job_list', 'display_subcategory_city', $lang, $this->_global_environment->get_cache_storage()
		);
		$small_backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_SMALL, 'job_list', 'display_subcategory_city', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options, $alt_backfill_options, $small_backfill_options);

		$view->display();
	}

	/**
	 * @param int $jobs_per_page
	 * @param array $list_criteria
	 * @param int $page_number
	 * @return int
	 */
	private function _calculate_job_count($jobs_per_page, array $list_criteria, $page_number) {
		list($db, , , $domain, $user_logged_in, ) = $this->_get_common();

		$job_searcher = Job::get_searcher(new Db_searcher($db));
		$job_list_searcher = new Static_job_list_searcher(
			$job_searcher, $domain, array_merge([$this->_global_environment->get_general_language()], $list_criteria), false, $user_logged_in
		);
		$total_job_count = $job_list_searcher->count_total_jobs($this->_global_environment->get_cache_storage());
		$job_count = $total_job_count - $jobs_per_page * ($page_number - 1);
		$job_count = max($job_count, 0);
		$job_count = min($job_count, $jobs_per_page);

		return $job_count;
	}

	/**
	 * Get formatted top cities
	 * @param State $current_state
	 * @param City $current_city
	 * @param int $top_city_count
	 * @return array [<array formatted top cities>, <string top_cities_heading>]
	 */
	private function _get_top_city_list(State $current_state, City $current_city, $top_city_count) {
		$db = $this->_general_env->get_db();
		$domain = $this->_global_environment->get_domain();
		$lang = $this->_global_environment->get_general_language();

		$top_city_list = new Top_job_city_list(
			$current_state,
			$db,
			$lang,
			$this->_get_container()->get_registered('SDB')
		);
		$top_cities = $top_city_list->get_formatted_cities($this->_url_manager, $top_city_count + 1);
		$city_list_state = $current_state;
		if (count($top_cities) == 1) {
			$neighbor_manager = new State_neighbor_manager($db, $current_state, new Job_counter($db));
			list($neighbor) = $neighbor_manager->get_most_jobs_neighbors(1);
			if (!is_null($neighbor)) {
				$neighbor = $neighbor->get_state();
				$neighbor->init(array('name'));
				$top_city_list = new Top_job_city_list(
					$neighbor,
					$db,
					$lang,
					$this->_get_container()->get_registered('SDB')
				);
				$top_cities = $top_city_list->get_formatted_cities($this->_url_manager, $top_city_count + 1);
				$city_list_state = $neighbor;
			}
		}
		else {
			$county = $current_city->get_county();
			if (!is_null($county)) {
				$county->init(array('name', 'state_id'));
				$county->state->init(array('name'));
				$county_page = new County_job_list_page($county);
				$curr_county = array(
					'name' => str_replace('County', 'Co.', $county->name), 'link' => $county_page->get_url($this->_url_manager, 1)
				);
				array_unshift($top_cities, $curr_county);
			}
		}
		if (count($top_cities) > $top_city_count) {
			unset($top_cities[count($top_cities) - 1]);
			$more = array();
			$more['name'] = $lang->get_text('TOP_CITIES_MORE_LINK');
			$more['link'] = $this->_url_manager->get_url(
				'city_list', 'list_job_state', array('state_url_name' => $city_list_state->get_url_name(), 'state_id' => $city_list_state->get_id())
			);
			$top_cities[] = $more;
		}
		return [
			$top_cities,
			str_replace(
				'{state_abbr}', $city_list_state->get_abbr(), $lang->get_text(is_null($neighbor) ? 'TOP_CITIES_HEADING' : 'TOP_CITIES_OTHER_HEADING')
			)
		];
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if region is invalid or does not have full job list, or there is not enough jobs to display given page
	 */
	private function _display_region_page($page_number) {
		list($db, $lang, $default_lang, $domain, , ) = $this->_get_common();
		$section = $this->_setup_site_section();

		if (!$section->region->get_has_full_job_list()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		//custom class for url handling
		$job_list_page = new Region_job_list_page($lang, $section->region);

		$options = new Job_list_display_options();
		$options->meta_page_number_params = $job_list_page->get_meta_page_number_params($page_number);
		if ($section->region->get_id() == Region::NORTH_AMERICA) {
			$options->job_shift = Region_job_list_page::NORTH_AMERICA_JOB_LIST_SHIFT;
		}
		if ($page_number == 1 || $page_number == 2) {
			$options->disable_search_link = true;
			$options->action = 'display_region_page';
		}
		$result = $this->_display_page(
			$page_number, $job_list_page, array($section->region), Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;

		$top_location_category_list_viewer = new Top_location_category_list_viewer($lang, $db, $this->_get_container()->get_registered('SDB'), $domain, $this->_url_manager);
		$top_location_category_list_viewer->assign_to_view($view, $section->region, null, $lang->get_text('TOP_COUNTRY_CAT'));

		$view->category_list_link = $this->_url_manager->get_url(
			'job_category_list', 'list_job_all_region', array('region_url_name' => $section->region->get_url_name($lang))
		);
		$view->category_list_link_caption = $lang->get_text('JOB_LIST_CATEGORY_LIST_LINK');

		if ($page_number == 1 || $page_number == 2) {
			$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
				'job_countries.php',
				date_create('tomorrow')->format('U') - date('U'),
				'region_countries_'.$lang->get_id().'_'.$section->region->get_id(),
				'loc_lists'
			);

			if (!$view->is_include_cached('job_countries.php')) {
				$searcher = Country::get_searcher(new Db_searcher($db));
				$searcher->set_region_search($section->region);
				$countries = $searcher->search();

				$formatter = new Job_country_list_formatter(
					$lang,
					$default_lang,
					Static_job_list_searcher::init_mergable_searcher(Job::get_searcher(new Db_searcher($db)), $domain, [$lang]),
					new Latest_job_manager($db, $this->_global_environment->get_cache_storage()),
					$this->_get_container()->get_registered('SDB'),
					[$lang]
				);
				$url_template = $this->_url_manager->get_url('job_list', 'display_country', array('country_url_name' => '<country_url_name>'));

				$view->countries = $formatter->format($countries, $url_template);
			}

			$view->set_include('job_countries', 'job_countries.php');
		}

		$view->all_categories_link = $this->_url_manager->get_url(
			'job_category_list', 'list_job_all_region', array('region_url_name' => $section->region->get_url_name($lang)));

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if specified parameters are invalid, or region does not have full job list, or there is not enough jobs
	 * to display given page
	 */
	private function _display_category_region_page($page_number) {
		$section = $this->_setup_site_section();

		if (!$section->region->get_has_full_job_list()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		list($db, $lang, , $domain, , ) = $this->_get_common();

		//custom class for url handling
		$job_list_page = new Category_region_job_list_page($lang, $section->region, $section->job_category, $section);

		$options = new Job_list_display_options();
		$options->meta_page_number_params = $job_list_page->get_meta_page_number_params($page_number);
		$result = $this->_display_page(
			$page_number, $job_list_page,
			array($section->region, $section->job_category), Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;

		$view->all_categories_link = $this->_url_manager->get_url(
			'job_category_list', 'list_job_all_region', array('region_url_name' => $_GET['region_url_name'])
		);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if specified parameters are invalid, or region does not have full job list, or there is not enough jobs
	 * to display given page
	 */
	private function _display_subcategory_region_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$current_route = $this->_get_current_route();

		$section = $this->_setup_site_section();

		$current_region = new Region($db, $current_route->get_specifying_param());
		if ((!in_array($current_region->get_id(), Region::get_subcat_job_lists_region_ids()) && !Jobs_app::get_test_mode())) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		$current_region->init();
		if (!$current_region->get_has_full_job_list()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		$section->region = $current_region; //since region is created from a specifying param, we need to set it explicitly, builder won't do it

		//custom class for url handling
		$job_list_page = new Subcategory_region_job_list_page($lang, $current_region, $section->job_subcategory);

		$options = new Job_list_display_options();
		$options->action = 'display_subcategory_region';
		$result = $this->_display_page(
			$page_number,
			$job_list_page,
			array($current_region, $section->job_subcategory),
			Formatted_job_list::LOCATION_LEVEL_COUNTRY,
			$options,
			$section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_subcategory_region', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	private function _display_category_country_page($page_number) {
		$section = $this->_setup_site_section();

		list($db, $lang, $default_lang, $domain, , $opt_man) = $this->_get_common();

		$job_list_page = new Job_list_page('display_category_country', $section);

		$options = new Job_list_display_options();
		$options->action = 'display_category_country';
		$location = new Location();
		$location->set_country($section->country);
		$result = $this->_display_page(
			$page_number,
			$job_list_page,
			array($location, $section->job_category),
			Formatted_job_list::LOCATION_LEVEL_COUNTRY,
			$options,
			$section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		if ($lang->get_id() == $default_lang->get_id()) {
			if ($section->country->get_id() == Country::USA) {
				$view->state_list_link = $this->_url_manager->get_url('state_list', 'list_job_category_country',
					array(
						'country_url_name' => $section->country->get_url_name($lang),
						'job_category_url_name' => $section->job_category->get_url_name($lang))
					);
				$view->state_list_link_caption = $lang->get_text('COUNTRY_JOB_LIST_STATE_LIST_LINK');
			}

			$enabled_page_manager = new Enabled_page_manager($db);
			if ($section->country->get_id() != Country::USA
				&& $enabled_page_manager->is_enabled(Enabled_page_manager::CAT_IMPORTANT_CITY, [$section->job_category])) {
				$job_searcher = Static_job_list_searcher::init_mergable_searcher(
					Job::get_searcher(new Db_searcher($db)), $domain, [$section->job_category]
				);
				$job_searcher->set_creation_date_search(new DateTime('-'.$opt_man->get_option('important_city_top_link_max_age_weeks').'weeks'));
				$formatter = new Job_city_list_formatter(
					$job_searcher,
					new Latest_job_manager($db, $this->_global_environment->get_cache_storage()),
					$this->_get_container()->get_registered('SDB'),
					[$section->job_category]
				);
				$formatter->set_job_count_filter(2);

				$c_searcher = City::get_searcher(new Db_searcher($db));
				$c_searcher->set_country_search($section->country);
				$c_searcher->set_is_important_search(true);

				$view->important_city_links = $formatter->format(
					$c_searcher->search(0, 0, ['name']),
					$this->_url_manager->get_url('job_list', 'display_category_important_city', [
						'country_short_name' => $section->country->get_url_name($lang, true),
						'job_category_url_name' => $section->job_category->get_url_name($lang),
						'city_url_name' => '<city_url_name>'
					]),
					['job_count'],
					Job_location_list_formatter::ORDER_JOB_COUNT
				);
			}
		}
		if ($this->_general_env->get_session()->get_value('from_404_job')) {
			$this->_general_env->get_session()->set_value('from_404_job', false);
			$view->from_404_job_msg = $lang->get_text('JOB_LIST_FROM_404_JOB');
		}

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_category_country', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	private function _display_subcategory_country_page($page_number) {
		$section = $this->_setup_site_section();

		list($db, $lang, $default_lang, , , ) = $this->_get_common();

		$job_list_page = new Job_list_page('display_subcategory_country', $section);

		$location = new Location(array($section->country));
		$options = new Job_list_display_options();
		$options->action = 'display_subcategory_country';
		$result = $this->_display_page(
			$page_number,
			$job_list_page,
			array($location, $section->job_subcategory),
			Formatted_job_list::LOCATION_LEVEL_COUNTRY,
			$options,
			$section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_subcategory_country', $lang, $this->_global_environment->get_cache_storage()
		);
		$loc_criteria = Backfill_job_list2::CRIT_COUNTRY;
		if ($section->country->get_id() != Country::USA) {
			$loc_criteria = Backfill_job_list2::CRIT_REGION;
			$section->region = $section->country->get_region();
		}
		$backfill_options->criteria[] = $loc_criteria;
		$small_backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_SMALL, 'job_list', 'display_subcategory_country', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options, null, $small_backfill_options);

		if ($lang->get_id() == $default_lang->get_id()) {
			if ($section->country->get_id() == Country::USA) {
				$view->state_list_link = $this->_url_manager->get_url('state_list', 'list_job_subcategory_country',
					array(
						'country_url_name' => $section->country->get_url_name($lang),
						'job_subcategory_url_name' => $section->job_subcategory->get_url_name($lang))
					);
				$view->state_list_link_caption = $lang->get_text('COUNTRY_JOB_LIST_STATE_LIST_LINK');
			}
		}

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	private function _display_subcategory_state_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$location = new Location(array($section->state));

		$job_list_page = new Job_list_page('display_subcategory_state', $section);

		$options = new Job_list_display_options();
		$options->action = 'display_subcategory_state';
		$options->under_location_url = City_job_list_page::get_job_activated_url(
			$this->_url_manager, $section->state, $section->job_subcategory, $lang
		);
		$result = $this->_display_page(
			$page_number,
			$job_list_page,
			array($location, $section->job_subcategory),
			Formatted_job_list::LOCATION_LEVEL_STATE,
			$options,
			$section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_subcategory_state', $lang, $this->_global_environment->get_cache_storage()
		);
		$alt_backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_ALT, 'job_list', 'display_subcategory_state', $lang, $this->_global_environment->get_cache_storage()
		);
		$small_backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_SMALL, 'job_list', 'display_subcategory_state', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options, $alt_backfill_options, $small_backfill_options);

		$params = array(
			'state_short_name' => $section->state->get_url_name(true),
			'state_id' => $section->state->get_id(),
			'job_subcategory_url_name' => $section->job_subcategory->get_url_name($lang)
		);
		$view->city_list_link = $this->_url_manager->get_url('city_list', 'list_job_subcategory_state', $params);
		$view->city_list_link_caption = $this->_global_environment->get_general_language()->get_text('STATE_JOB_LIST_SEARCH_BY_CITY_LINK');
		$view->display();
	}

	/**
	 * @throws Pag_not_found_exception if state is not correctly specified or there is not enough jobs to display given page
	 */
	public function display_county_page_action() {
		$route = $this->_get_current_route();
		$page_number = !is_null($route) && $route->get_specifying_param() ? $route->get_specifying_param() : $_GET['page_number'];

		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$location = new Location(array($section->county));
		$options = new Job_list_display_options();
		$result = $this->_display_page(
			$page_number, new County_job_list_page($section->county),
			array($location), Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_county_page', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

    /**
	 * Display part time jobs in a specific country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
    public function display_part_time_country_action() {
		$this->_display_part_time_country_page(1);
	}

	/**
	 * Display part time jobs in a specific country on a specific page.
	 * Works exactly like display_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
	public function display_part_time_country_page_action() {
		$this->_display_part_time_country_page($_GET['page_number']);
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
	private function _display_part_time_country_page($page_number) {
		$section = $this->_setup_site_section();

		if (($section->country->get_id() != Country::USA && !App::get_test_mode())) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		list($db, $lang, , $domain, , ) = $this->_get_common();

		$job_list_page = new Job_list_page('display_part_time_country', $section);

		$options = new Job_list_display_options();
		$options->action = 'display_part_time_country';
		$list_criteria = array(new Location(array($section->country)), new Employment_type($db, Employment_type::ID_PART_TIME));

		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;

		$view->state_list_link = $this->_url_manager->get_url('state_list', 'list_part_time_job_country',
			array('country_url_name' => $section->country->get_url_name($lang)));
		$view->state_list_link_caption = $lang->get_text('COUNTRY_JOB_LIST_STATE_LIST_LINK');

		$view->display();
	}

	/**
	 * Display part time jobs in a specific country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
    public function display_part_time_state_action() {
		$this->_display_part_time_state_page(1);
	}

	/**
	 * Display part time jobs in a specific country on a specific page.
	 * Works exactly like display_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
	public function display_part_time_state_page_action() {
		$this->_display_part_time_state_page($_GET['page_number']);
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
	private function _display_part_time_state_page($page_number) {
		list($db, $lang, , $domain, , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_part_time_state', $section);

		$options = new Job_list_display_options();
		$options->action = 'display_part_time_state';
		$options->under_location_url = City_part_time_job_list_page::get_job_activated_url($this->_url_manager, $section->state);

		$list_criteria = array(new Location(array($section->state)), new Employment_type($db, Employment_type::ID_PART_TIME));

		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_STATE, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;

		$view->city_list_link = $this->_url_manager->get_url('city_list', 'list_part_time_job_state',
				array('state_url_name' => $section->state->get_url_name(), 'state_id' => $section->state->get_id()));
		$view->city_list_link_caption = $this->_global_environment->get_general_language()->get_text('STATE_JOB_LIST_SEARCH_BY_CITY_LINK');
		$view->display();
	}

	/**
	 * Display part time jobs in a specific country.
	 * Displays the first page.
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
    public function display_part_time_city_action() {
		$this->_display_part_time_city_page(1);
	}

	/**
	 * Display part time jobs in a specific country on a specific page.
	 * Works exactly like display_country_action() but specifies a page number.
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
	public function display_part_time_city_page_action() {
		$this->_display_part_time_city_page($_GET['page_number']);
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if location parameters can not be matched or resulting list is empty.
	 */
	private function _display_part_time_city_page($page_number) {
		list($db, $lang, , $domain, , ) = $this->_get_common();

		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_part_time_city', $section);

		$location = new Location(array($section->city));
		$list_criteria = array($location, new Employment_type($db, Employment_type::ID_PART_TIME));

		$job_list_options = $this->_get_all_job_list_options('display_part_time_city', $page_number);

		$job_count = $this->_calculate_job_count($job_list_options['jobs_per_page'], $list_criteria, $page_number);
		$top_city_count = $this->_get_top_city_count($job_count);
		list($top_cities, $top_cities_heading) = $this->_get_top_city_list($section->state, $section->city, $top_city_count);

		$options = new Job_list_display_options();
		$options->action = 'display_part_time_city';
		$options->formatted_top_cities = $top_cities;
		$options->job_list_options = $job_list_options;
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_CITY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;
		$view->top_cities_heading = $top_cities_heading;

		$view->cities = $top_cities;
		$view->set_include('top_cities', 'top_cities.php');
		$view->display();
	}

	/**
	 * @param array $jobs
	 * @param array $pages
	 * @param Country|null $current_country
	 * @param bool $display_footer
	 * @param Site_section|null $section
	 * @param Afs_display_manager|bool|null $afs_manager
	 * If null is passed, a default AFS manager is created, if false is passed, no AFS will be displayed.
	 * @return General_view
	 */
	private function _get_view(array $jobs = null, array $pages = null, Country $current_country = null, $display_footer = true, Site_section $section = null, $afs_manager = null, $hide_ads = false) {
		if ($afs_manager === false) {
			$afs_manager = null;
		}
		else {
			$afs_manager = $afs_manager ?: new Afs_display_manager($this->_get_geoip_country());
		}
		$view = $this->_create_view($current_country, $display_footer, $section, $afs_manager, 'new_main.php', $hide_ads);
		$this->_assign_share_buttons($view);

		$view->next_page = $pages['next'];
		$view->prev_page = $pages['prev'];
		$view->page_links = $pages['pages'];
		$view->current_pg_offset = $pages['current_offset'];

		$view->jobs = $jobs;

		$view->set_include('content', 'job_list.php');
		$view->total_item_count_string = 'TOTAL_JOB_COUNT';
		//$view->set_css('pagination.css'); //ucomment if top pagination include is removed again
		$view->set_include('pagination', 'pagination.php');
		$view->set_include('pagination_bottom', 'pagination_bottom.php');
		$view->set_include('jobs', 'jobs.php');

		return $view;
	}

	/**
	 * @return array
	 */
	protected function _get_access_rules() {
		$parent_rules = parent::_get_access_rules();
		$rule = new App_action_access_rule(array(
			'display_all_page', 'display_category_country_page', 'display_category_region_page', 'display_country_page',
			'display_employer_page', 'display_category_page'
		));
		$rule->set_check('page_number', App_action_access_rule::RULE_GREATER_ZERO);
		return array_merge($parent_rules, array($rule));
	}

	/**
	 * @param int $page_number
	 * @param int $total_job_count
	 * @param int $jobs_per_page
	 * @param int $max_page_nr
	 * @param Job_list_page $job_list_page
	 * @param int $shift from which job we are listing (count is simply total count irrespective of shift so we need this)
	 * @return array
	 */
	private function _get_pages($page_number, $total_job_count, $jobs_per_page, $max_page_nr, Job_list_page $job_list_page, $shift = 0) {
		$max_job_count = $max_page_nr * $jobs_per_page;
		if ($total_job_count > $max_job_count + $shift) {
			$total_job_count = $max_job_count + $shift;
		}
		$paginator = new Paginator($total_job_count, $jobs_per_page, self::NUM_PAGINATION_LINKS, $page_number, $shift);
		$paginator_formatter = new Linkable_list_paginator_formatter($paginator, $this->_url_manager);
		return $this->_label_pages($paginator_formatter->format_paginator($job_list_page));
	}

	/**
	 * Get common variables needed on job lists
	 * @return array array($db, $lang, $default_lang, $domain, $user_logged_in, $options_manager)
	 */
	private function _get_common() {
		return array(
			$this->_general_env->get_db(),
			$this->_global_environment->get_general_language(),
			App_language::get_default_general_language($this->_general_env->get_db()),
			$this->_global_environment->get_domain(),
			!is_null($this->_global_environment->get_jobseeker_environment()->get_user())
				|| !is_null($this->_global_environment->get_employer_environment()->get_user()),
			new Options_manager($this->_general_env->get_db())
		);
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid country given or there is not enough jobs to display given page
	 */
	private function _display_country_bachelor_page($page_number) {
		list($db, $lang, $default_lang, , , ) = $this->_get_common();
		$enabled_page_manager = new Enabled_page_manager($db);

		$level = new Education_level($db, Education_level::BACHELOR);
		$section = $this->_setup_site_section();
		$section->education_level = $level;

		if ($lang->get_id() != $default_lang->get_id()
			|| !$enabled_page_manager->is_enabled(Enabled_page_manager::BACHELOR_PAGES, [$section->country])) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$job_list_page = new Job_list_page('display_country_bachelor', $section);

		$options = new Job_list_display_options();
		$options->action = 'display_country_bachelor';
		$result = $this->_display_page(
			$page_number, $job_list_page, [new Location([$section->country]), $level], Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section
		);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		if ($section->country->get_id() == Country::USA) {
			$view->state_list_link = $this->_url_manager->get_url('state_list', 'list_job_country_bachelor', [
				'country_short_name' => $section->country->get_url_name($lang, true)
			]);
			$view->state_list_link_caption = $lang->get_text('COUNTRY_JOB_LIST_STATE_LIST_LINK');


			$view->category_list_link = $this->_url_manager->get_url('job_category_list', 'list_job_country_bachelor', [
				'country_short_name' => $section->country->get_url_name($lang, true)
			]);
			$view->category_list_link_caption = $lang->get_text('JOB_LIST_CATEGORY_LIST_LINK');
		}

		$section->region = $section->country->get_region();
		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_country_bachelor', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	private function _display_category_country_bachelor_page($page_number) {
		list($db, $lang, $default_lang, , , ) = $this->_get_common();

		$level = new Education_level($db, Education_level::BACHELOR);
		$section = $this->_setup_site_section();
		$section->education_level = $level;

		$manager = new Enabled_page_manager($db);

		if ($lang->get_id() != $default_lang->get_id()
			|| !$manager->is_enabled(Enabled_page_manager::BACHELOR_PAGES, [$section->country, $section->job_category])) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		$section->country->init();

		$options = new Job_list_display_options();
		$options->action = 'display_category_country_bachelor';
		$location = new Location([$section->country]);
		$page = new Job_list_page('display_category_country_bachelor', $section);
		$result = $this->_display_page(
			$page_number, $page, [$location, $section->job_category, $level], Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section
		);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		if ($section->country->get_id() == Country::USA) {
			$view->state_list_link = $this->_url_manager->get_url('state_list', 'list_job_category_country_bachelor', [
				'country_short_name' => $section->country->get_url_name($lang, true),
				'job_category_url_name' => $section->job_category->get_url_name($lang)
			]);
			$view->state_list_link_caption = $lang->get_text('COUNTRY_JOB_LIST_STATE_LIST_LINK');
		}

		$section->region = $section->country->get_region();
		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_category_country_bachelor', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	private function _display_subcategory_country_bachelor_page($page_number) {
		list($db, $lang, $default_lang, , , ) = $this->_get_common();

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);

		$manager = new Enabled_page_manager($db);
		if ($lang->get_id() != $default_lang->get_id()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		if (!$manager->is_enabled(Enabled_page_manager::BACHELOR_PAGES, [$section->country, $section->job_category])) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$job_list_page = new Job_list_page('display_subcategory_country_bachelor', $section);

		$location = new Location([$section->country]);
		$options = new Job_list_display_options();
		$options->action = 'display_subcategory_country_bachelor';
		$result = $this->_display_page(
			$page_number,
			$job_list_page,
			[$location, $section->job_subcategory, $section->education_level],
			Formatted_job_list::LOCATION_LEVEL_COUNTRY,
			$options,
			$section
		);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		if ($section->country->get_id() == Country::USA) {
			$view->state_list_link = $this->_url_manager->get_url('state_list', 'list_job_subcategory_country_bachelor', [
				'country_short_name' => $section->country->get_url_name($lang, true),
				'job_subcategory_url_name' => $section->job_subcategory->get_url_name($lang)
			]);
			$view->state_list_link_caption = $lang->get_text('COUNTRY_JOB_LIST_STATE_LIST_LINK');
		}

		$section->region = $section->country->get_region();
		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_subcategory_country_bachelor', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if parameters are specified incorectly or there is not enough jobs to display given page
	 */
	private function _display_city_bachelor_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		$job_list_page = new Job_list_page('display_city_bachelor', $section);
		$list_criteria = [new Location([$section->city]), $section->education_level];

		$options = new Job_list_display_options();
		$options->action = 'display_city_bachelor';
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_CITY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_city_bachelor_page', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if parameters are specified incorectly or there is not enough jobs to display given page
	 */
	private function _display_category_city_bachelor_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		$job_list_page = new Job_list_page('display_category_city_bachelor', $section);
		$list_criteria = [new Location([$section->city]), $section->job_category, $section->education_level];

		$options = new Job_list_display_options();
		$options->action = 'display_category_city_bachelor';
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_CITY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_category_city_bachelor_page', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if parameters are specified incorectly or there is not enough jobs to display given page
	 */
	private function _display_subcategory_city_bachelor_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		$job_list_page = new Job_list_page('display_subcategory_city_bachelor', $section);
		$list_criteria = [new Location([$section->city]), $section->job_subcategory, $section->education_level];

		$options = new Job_list_display_options();
		$options->action = 'display_subcategory_city_bachelor';
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_CITY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_subcategory_city_bachelor_page', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if state is not correctly specified or there is not enough jobs to display given page
	 */
	private function _display_state_bachelor_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		$job_list_page = new Job_list_page('display_state_bachelor', $section);
		$list_criteria = [new Location([$section->state]), $section->education_level];

		$options = new Job_list_display_options();
		$options->action = 'display_state_bachelor';
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_STATE, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$view->category_list_link = $this->_url_manager->get_url('job_category_list', 'list_job_state_bachelor',
			['state_short_name' => $section->state->get_url_name(true), 'state_id' => $section->state->get_id()]);
		$view->category_list_link_caption = $lang->get_text('JOB_LIST_CATEGORY_LIST_LINK');

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_state_bachelor_page', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if request parameters are specified incorectly or there is not enough jobs to display given page
	 */
	private function _display_category_state_bachelor_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		$job_list_page = new Job_list_page('display_category_state_bachelor', $section);
		$list_criteria = [new Location([$section->state]), $section->education_level, $section->job_category];

		$options = new Job_list_display_options();
		$options->action = 'display_category_state_bachelor';
		$result = $this->_display_page(
			$page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_STATE, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_category_state_bachelor_page', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * @param int $page_number
	 * @throws Page_not_found_exception if invalid request parameters are given, or there is no jobs with given parameters
	 */
	private function _display_subcategory_state_bachelor_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		$job_list_page = new Job_list_page('display_subcategory_state_bachelor', $section);
		$list_criteria = [new Location([$section->state]), $section->job_subcategory, $section->education_level];

		$options = new Job_list_display_options();
		$options->action = 'display_subcategory_state_bachelor';
		$result = $this->_display_page($page_number, $job_list_page, $list_criteria, Formatted_job_list::LOCATION_LEVEL_STATE, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_subcategory_state_bachelor', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}

	/**
	 * Important city job list
	 */
	public function display_important_city_action() {
		$this->_display_important_city_page(1);
	}

	/**
	 * Important city job list
	 */
	public function display_important_city_page_action() {
		$this->_display_important_city_page($_GET['page_number']);
	}

	/**
	 * @param int $page_number
	 */
	private function _display_important_city_page($page_number) {
		$section = $this->_setup_site_section();

		$job_list_page = new Job_list_page('display_important_city', $section);
		$options = new Job_list_display_options();
		$options->action = 'display_important_city';
		$result = $this->_display_page(
			$page_number, $job_list_page, [new Location([$section->city])], Formatted_job_list::LOCATION_LEVEL_COUNTRY, $options, $section);

		if (!$result) {
			return;
		}

		list($view, , ) = $result;

		$view->display();
	}

	/**
	 * Category important city job list
	 */
	public function display_category_important_city_action() {
		$this->_display_category_important_city_page(1);
	}

	/**
	 * Category important city job list
	 */
	public function display_category_important_city_page_action() {
		$this->_display_category_important_city_page($_GET['page_number']);
	}

	/**
	 * @param int $page_number
	 */
	private function _display_category_important_city_page($page_number) {
		list($db, $lang, , , , ) = $this->_get_common();
		$section = $this->_setup_site_section();
		$enabled_page_manager = new Enabled_page_manager($db);
		if (!$enabled_page_manager->is_enabled(Enabled_page_manager::CAT_IMPORTANT_CITY, [$section->job_category])) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$job_list_page = new Job_list_page('display_category_important_city', $section);
		$options = new Job_list_display_options();
		$options->action = 'display_category_important_city';
		$result = $this->_display_page(
			$page_number,
			$job_list_page,
			[new Location([$section->city]), $section->job_category],
			Formatted_job_list::LOCATION_LEVEL_COUNTRY,
			$options,
			$section
		);

		if (!$result) {
			return;
		}

		list($view, , $unformatted_jobs) = $result;

		$backfill_options = new Backfill_options(
			$db, Backfill_job_list2::TYPE_MAIN, 'job_list', 'display_category_important_city', $lang, $this->_global_environment->get_cache_storage()
		);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view->display();
	}
}
