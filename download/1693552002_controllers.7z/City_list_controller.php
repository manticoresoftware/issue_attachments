<?php
/**
 * Controller for displaying states city list.
 * @package controllers
 */
class City_list_controller extends General_controller {
	
	use Job_list_fragment;

	const TOP_CAT_COUNT = 15;

	const META_TOP_CITIES_COUNT = 3;
	
	/**
	 * Create page criteria models from GET parameters and assign them to a site section.
	 * @return Site_section
	 * @throws Page_not_found_exception If current URL parameters are invalid.
	 */
	private function _setup_site_section() {
		$section_builder = new Site_section_builder(
			$this->_general_env->get_db(), $this->_global_environment->get_general_language(), $this->_global_environment->get_cache_storage()
		);
		try {
			$section = $section_builder->build_site_section($_GET, $_SERVER['REQUEST_URI']);
		}
		catch (\InvalidArgumentException $e) {
			throw new \Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		$section->is_location_list = true;
		$section->is_city_list = true;
		
		return $section;
	}
	
	/**
	 * List states cities that have jobs.
	 */
	public function list_job_state_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$domain = $this->_global_environment->get_domain();
		$opt_man = new Options_manager($db);
		$cache = $this->_global_environment->get_cache_storage();

		$section = $this->_setup_site_section();
		$view = $this->_create_view($section->state->get_country(), true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'job_location_list_v2.php', date_create('tomorrow')->format('U') - date('U'), 'state_cities_'.$section->state->get_id(), 'loc_lists'
		);

		if (!$view->is_include_cached('job_location_list_v2.php')) {
			$searcher = City::get_searcher(new Db_searcher($db));
			$searcher->set_state_search($section->state);
			$cities = $searcher->search();

			$formatter = new Job_city_list_formatter(
				Static_job_list_searcher::init_mergable_searcher(Job::get_searcher(new Db_searcher($db)), $domain, [$lang]),
				new Latest_job_manager($db, $cache),
				$this->_get_container()->get_registered('SDB'),
				[$lang]
			);
			$params = array(
				'state_url_name' => $section->state->get_url_name(),
				'city_id' => '<city_id>',
				'city_url_name' => '<city_url_name>',
				'specifying_param' => 1);
			$url_template = $this->_url_manager->get_url('job_list', 'display_city_page', $params);
			$view->locations = $formatter->format($cities, $url_template);
			if (!$view->locations) {
				$this->_redirect($this->_url_manager->get_url('job_list', 'display_state', [
					'state_url_name' => $section->state->get_url_name(),
					'state_id' => $section->state->get_id(),
					'country_url_name' => $section->country->get_url_name($lang)
				]));
				return;
			}

			$view->counties = $this->_get_counties($section->state);
		}

		$formatter_builder = new Job_list_formatter_builder(
			$this->_global_environment, $this->_url_manager, $cache
		);
		$list_formatter = $formatter_builder->build_job_list_formatter();
		$list_formatter->set_location_format('{short_state}(- - {city} -)');
		$location = new Location();
		$location->set_state($section->state);
		$list_criteria = [$location, $lang];
		$short_job_list = new Short_job_list(
			Sphinx_job_list_searcher::get_fresh($db, $domain, $list_criteria),
			new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_STATE)
		);

		$view->jobs = $short_job_list->get_formatted_jobs($lang, 0, 2, $this->_get_ip_country(), $unformatted_jobs);
		$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(), Formatted_job_list::LOCATION_LEVEL_STATE);
		Top_job_table::assign_formatted_jobs($this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), [$location, $lang]);

		$top_location_subcategory_list_viewer = new Top_location_subcategory_list_viewer($lang, $db, $domain, $this->_url_manager);
		$top_location_subcategory_list_viewer->assign_to_view(
			$view, $opt_man->get_option('count_bottom_overall_subcat'), $section->state, 'TOP_LOC_OVERALL_SUBCAT'
		);
		
		//source test for this part is in JobListTest
		$backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_MAIN, 'city_list', 'list_job_state', $lang);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$top_location_category_list_viewer = new Top_location_category_list_viewer($lang, $db, $this->_get_container()->get_registered('SDB'), $domain, $this->_url_manager);
		$top_location_category_list_viewer->assign_to_view($view, $section->state);

		$view = $this->_setup_view(
			$view,
			$section,
			array_merge($this->_get_cat_sub_counts($section, $list_criteria), $this->_get_meta_variables($section->state, $view->jobs))
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
		$view->set_css('job_list.css');
		$view->set_include('job_location_list', 'job_location_list_v2.php');
		$view->set_include('content', 'job_location_list_page.php');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
		$view->display();
	}

	/**
	 * @param State $current_state
	 * @return array
	 */
	private function _get_counties(State $current_state) {
		$db = $this->_general_env->get_db();
		$county_searcher = County::get_searcher(new Db_searcher($db));
		$county_searcher->set_state_search($current_state);
		$counter = new Job_counter($db);
		$counties = $counter->get_top_counties(21, $county_searcher->search());
		foreach ($counties as $county) {
			$county->init(array('name', 'state_id'));
		}
		$formatted_counties = array();
		foreach ($counties as $county) {
			$county->state->init(array('name'));
			$county_section = new Site_section();
			$county_section->state = $county->state;
			$county_section->county = $county;
			$formatted_counties[] = array(
				'link' => $this->_url_manager->get_site_section_url('job_list', 'display_county_page', $county_section, ['specifying_param' => 1]), 
				'name' => $county->name);
		}
		return $formatted_counties;
	}
	
	/**
	 * Old action for redirection from old URLs to new ones.
	 */
	public function list_job_category_state_old_action() {
		$section = $this->_setup_site_section();
		
		$this->_redirect($this->_url_manager->get_url(
				'city_list', 'list_job_category_state', array(
					'state_short_name' => $section->state->get_url_name(true), 
					'job_category_url_name' => $_GET['job_category_url_name'], 
					'state_id' => $_GET['state_id'])), 
				301);
	}

	/**
	 * List states cities that have jobs.
	 */
	public function list_job_category_state_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$domain = $this->_global_environment->get_domain();
		$opt_man = new Options_manager($db);
		$cache = $this->_global_environment->get_cache_storage();

		$section = $this->_setup_site_section();
		$view = $this->_create_view($section->state->get_country(), true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'job_location_list_v2.php',
			date_create('tomorrow')->format('U') - date('U'),
			'state_category_cities_'.$section->state->get_id().'_'.$section->job_category->get_id(),
			'loc_lists'
		);

		if (!$view->is_include_cached('job_location_list_v2.php')) {
			$searcher = City::get_searcher(new Db_searcher($db));
			$searcher->set_state_search($section->state);
			$cities = $searcher->search();
			
			$formatter = new Job_city_list_formatter(
				Static_job_list_searcher::init_mergable_searcher(Job::get_searcher(new Db_searcher($db)), $domain, [$section->job_category, $lang]),
				new Latest_job_manager($db, $cache),
				$this->_get_container()->get_registered('SDB'),
				[$section->job_category, $lang]
			);
			$url_template = $this->_url_manager->get_site_section_url('job_list', 'display_category_city', $section);
			$view->locations = $formatter->format(
				$cities, $url_template, array('job_count', 'last_job_titles'), Job_location_list_formatter::ORDER_JOB_COUNT
			);
			if (!$view->locations) {
				$this->_redirect($this->_url_manager->get_url('job_list', 'display_category_state', [
					'job_category_url_name' => $_GET['job_category_url_name'],
					'state_short_name' => $section->state->get_url_name(true),
					'state_id' => $section->state->get_id()
				]));
				return;
			}
			$view->number_of_columns = 1;
		}

		$formatter_builder = new Job_list_formatter_builder($this->_global_environment, $this->_url_manager, $cache);
		$list_formatter = $formatter_builder->build_job_list_formatter();
		$list_formatter->set_location_format('{short_state}(- - {city} -)');
		$location = new Location();
		$location->set_state($section->state);
		$list_criteria = [$location, $section->job_category, $lang];
		$short_job_list = new Short_job_list(
			Sphinx_job_list_searcher::get_fresh($db, $domain, $list_criteria),
			new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_STATE)
		);

		$view->jobs = $short_job_list->get_formatted_jobs($lang, 0, 2, $this->_get_ip_country(), $unformatted_jobs);
		$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(), Formatted_job_list::LOCATION_LEVEL_STATE);
		Top_job_table::assign_formatted_jobs(
			$this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), [$location, $section->job_category, $lang]
		);
		
		//source test for this part is in JobListTest
		$backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_MAIN, 'city_list', 'list_job_category_state', $lang);
		$alt_backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_ALT, 'city_list', 'list_job_category_state', $lang);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options, $alt_backfill_options);

		$meta_variables = $this->_get_meta_variables($section->state, $view->jobs);
		$meta_variables['{category}'] = $section->job_category->get_name($lang);
		$view = $this->_setup_view(
			$view,
			$section,
			array_merge($this->_get_cat_sub_counts($section, $list_criteria), $meta_variables)
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
		$view->set_css('job_list.css');
		$view->set_include('job_location_list', 'job_location_list_v2.php');
		$view->set_include('content', 'job_location_list_page.php');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
		$view->display();
	}

	/**
	 * List cities that have part time jobs.
	 */
	public function list_part_time_job_state_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$domain = $this->_global_environment->get_domain();
		$cache = $this->_global_environment->get_cache_storage();

		$section = $this->_setup_site_section();
		$view = $this->_create_view($section->state->get_country(), true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'job_location_list_v2.php', date_create('tomorrow')->format('U') - date('U'), 'part_time_state_cities'.$section->state->get_id(), 'loc_lists'
		);


		if (!$view->is_include_cached('job_location_list_v2.php')) {
			$searcher = City::get_searcher(new Db_searcher($db));
			$searcher->set_state_search($section->state);
			$cities = $searcher->search();

			$formatter = new Job_city_list_formatter(
				Static_job_list_searcher::init_mergable_searcher(
					Job::get_searcher(new Db_searcher($db)), $domain, [new Employment_type($db, Employment_type::ID_PART_TIME), $lang]
				),
				new Latest_job_manager($db, $cache),
				$this->_get_container()->get_registered('SDB'),
				[new Employment_type($db, Employment_type::ID_PART_TIME), $lang]
			);
			$url_template = $this->_url_manager->get_url('job_list', 'display_part_time_city', array(
				'state_url_name' => $section->state->get_url_name(), 'city_id' => '<city_id>', 'city_url_name' => '<city_url_name>')
			);
			$view->locations = $formatter->format($cities, $url_template, array('job_count'), Job_location_list_formatter::ORDER_JOB_COUNT);
			if (!$view->locations) {
				$this->_redirect($this->_url_manager->get_url('job_list', 'display_part_time_state', [
					'state_url_name' => $section->state->get_url_name(), 'state_id' => $section->state->get_id()
				]));
				return;
			}
		}

		$formatter_builder = new Job_list_formatter_builder($this->_global_environment, $this->_url_manager, $cache);
		$list_formatter = $formatter_builder->build_job_list_formatter();
		$list_formatter->set_location_format('{short_state}(- - {city} -)');
		$location = new Location();
		$location->set_state($section->state);
		$list_criteria = [$location, new Employment_type($db, Employment_type::ID_PART_TIME), $lang];
		$short_job_list = new Short_job_list(
			Sphinx_job_list_searcher::get_fresh($db, $domain, $list_criteria),
			new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_STATE)
		);

		$view->jobs = $short_job_list->get_formatted_jobs($lang, 0, 2, $this->_get_ip_country());
		$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(), Formatted_job_list::LOCATION_LEVEL_STATE);
		Top_job_table::assign_formatted_jobs(
			$this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), [$location, new Employment_type($db, Employment_type::ID_PART_TIME), $lang]
		);
		
		$view = $this->_setup_view(
			$view,
			$section,
			array_merge($this->_get_cat_sub_counts($section, $list_criteria), $this->_get_meta_variables($section->state, $view->jobs))
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
		$view->set_css('job_list.css');
		$view->set_include('job_location_list', 'job_location_list_v2.php');
		$view->set_include('content', 'job_location_list_page.php');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
		$view->display();
	}

	/**
	 * List states cities that have jobs.
	 */
	public function list_job_subcategory_state_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$cache = $this->_global_environment->get_cache_storage();
		$domain = $this->_global_environment->get_domain();
		$opt_man = new Options_manager($db);

		$section = $this->_setup_site_section();
		$view = $this->_create_view($section->state->get_country(), true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'job_location_list_v2.php',
			date_create('tomorrow')->format('U') - date('U'),
			'state_subcategory_cities_'.$section->state->get_id().'_'.$section->job_subcategory->get_id(),
			'loc_lists'
		);

		if (!$view->is_include_cached('job_location_list_v2.php')) {
			$city_list_searcher = new Job_city_list_searcher(
				$domain,
				City::get_searcher(new Db_searcher($db)),
				Job::get_searcher(new Db_searcher($db)),
				array($section->state, $section->job_subcategory)
			);

			$cities = $city_list_searcher->find_cities();
			
			$formatter = new Job_city_list_formatter(
				Static_job_list_searcher::init_mergable_searcher(Job::get_searcher(new Db_searcher($db)), $domain, [$section->job_subcategory, $lang]),
				new Latest_job_manager($db, $cache),
				$this->_get_container()->get_registered('SDB'),
				[$section->job_subcategory, $lang]
			);
			$params = array(
				'state_short_name' => $section->state->get_url_name(true),
				'city_id' => '<city_id>',
				'city_url_name' => '<city_url_name>',
				'job_subcategory_url_name' => $_GET['job_subcategory_url_name']);
			$url_template = $this->_url_manager->get_url('job_list', 'display_subcategory_city', $params);
			$view->locations = $formatter->format(
				$cities, $url_template, array('job_count', 'last_job_titles'), Job_location_list_formatter::ORDER_JOB_COUNT
			);
			if (!$view->locations) {
				$this->_redirect($this->_url_manager->get_url('job_list', 'display_subcategory_state', [
					'job_subcategory_url_name' => $_GET['job_subcategory_url_name'],
					'state_short_name' => $section->state->get_url_name(true),
					'state_id' => $section->state->get_id()
				]));
				return;
			}
			$view->number_of_columns = 1;
		}

		$formatter_builder = new Job_list_formatter_builder($this->_global_environment, $this->_url_manager, $cache);
		$list_formatter = $formatter_builder->build_job_list_formatter();
		$list_formatter->set_location_format('{short_state}(- - {city} -)');
		$list_formatter->set_short_empl_desc_length($opt_man->get_option('short_empl_desc_length'));
		$location = new Location();
		$location->set_state($section->state);
		$list_criteria = [$location, $section->job_subcategory, $lang];
		$short_job_list = new Short_job_list(
			Sphinx_job_list_searcher::get_fresh($db, $domain, $list_criteria),
			new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_STATE, true)
		);

		$view->jobs = $short_job_list->get_formatted_jobs($lang, 0, 2, $this->_get_ip_country(), $unformatted_jobs);
		$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(), Formatted_job_list::LOCATION_LEVEL_STATE);
		Top_job_table::assign_formatted_jobs(
			$this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), [$location, $section->job_subcategory, $lang]
		);

		$backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_MAIN, 'city_list', 'list_job_subcategory_state', $lang);
		$small_backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_SMALL, 'city_list', 'list_job_subcategory_state', $lang);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options, null, $small_backfill_options);
		
		$meta_variables = $this->_get_meta_variables($section->state, $view->jobs);
		$meta_variables['{category}'] = $section->job_category->get_name($lang);
		$meta_variables['{subcategory}'] = $section->job_subcategory->get_name($lang);
		$view = $this->_setup_view(
			$view,
			$section,
			array_merge($this->_get_cat_sub_counts($section, $list_criteria), $meta_variables)
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
		$view->set_css('job_list.css');
		$view->set_include('job_location_list', 'job_location_list_v2.php');
		$view->set_include('content', 'job_location_list_page.php');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
		$view->display();
	}

	/**
	 * @param State $current_state
	 * @param array $formatted_jobs
	 * @return array Array of meta variables
	 */
	private function _get_meta_variables(State $current_state, array $formatted_jobs = array()) {
		$db = $this->_general_env->get_db();
		$top_city_list = new Top_job_city_list(
			$current_state,
			$db,
			$this->_global_environment->get_general_language(),
			$this->_get_container()->get_registered('SDB')
		);
		$top_cities = $top_city_list->get_formatted_cities($this->_url_manager, self::META_TOP_CITIES_COUNT, true);

		return array('{state}' => $current_state->get_short_name(), '{state_abbr}' => $current_state->get_abbr(),
			'{city1}' => $top_cities[0]['name'], '{city2}' => $top_cities[1]['name'], '{city3}' => $top_cities[2]['name'],
			'{last_job_titles}' => Meta_handler::get_last_job_titles($formatted_jobs));
	}

	/**
	 * List states cities that have jobs.
	 */
	public function list_job_state_bachelor_action() {
		$db = $this->_general_env->get_db();
		$lang = $this->_global_environment->get_general_language();
		$default_lang = App_language::get_default_general_language($db);
		$domain = $this->_global_environment->get_domain();
		$cache = $this->_global_environment->get_cache_storage();

		$level = new Education_level($db, Education_level::BACHELOR);

		$section = $this->_setup_site_section();
		$section->education_level = $level;
		
		if ($lang->get_id() != $default_lang->get_id() || $section->country->get_id() != Country::USA) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$view = $this->_create_view($section->state->get_country(), true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'job_location_list_v2.php', date_create('tomorrow')->format('U') - date('U'), 'state_cities_bachelor_'.$section->state->get_id(), 'loc_lists'
		);

		if (!$view->is_include_cached('job_location_list_v2.php')) {
			$searcher = City::get_searcher(new Db_searcher($db));
			$searcher->set_state_search($section->state);
			$cities = $searcher->search();

			$formatter = new Job_city_list_formatter(
			Static_job_list_searcher::init_mergable_searcher(Job::get_searcher(new Db_searcher($db)), $domain, [$level, $lang]),
				new Latest_job_manager($db, $cache),
				$this->_get_container()->get_registered('SDB'),
				[$level, $lang]
			);
			$url_template = $this->_url_manager->get_url('job_list', 'display_city_bachelor', [
				'state_abbr' => strtolower($section->state->get_abbr()), 'city_id' => '<city_id>', 'city_url_name' => '<city_url_name>'
			]);
			$view->locations = $formatter->format($cities, $url_template);
			if (!$view->locations) {
				$this->_redirect($this->_url_manager->get_url('job_list', 'display_state_bachelor', [
					'state_short_name' => $section->state->get_url_name(true), 'state_id' => $section->state->get_id()
				]));
				return;
			}
		}

		$formatter_builder = new Job_list_formatter_builder($this->_global_environment, $this->_url_manager, $cache);
		$list_formatter = $formatter_builder->build_job_list_formatter();
		$list_formatter->set_location_format('{short_state}(- - {city} -)');
		$location = new Location([$section->state]);
		$list_criteria = [$location, $level, $lang];
		$short_job_list = new Short_job_list(
			Sphinx_job_list_searcher::get_fresh($db, $domain, $list_criteria),
			new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_STATE)
		);

		$view->jobs = $short_job_list->get_formatted_jobs($lang, 0, 2, $this->_get_ip_country(), $unformatted_jobs);
		$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(), Formatted_job_list::LOCATION_LEVEL_STATE);
		Top_job_table::assign_formatted_jobs(
		    $this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), [$location, $level, $lang]
		);
		
		$backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_MAIN, 'city_list', 'list_job_state_bachelor', $lang);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$view = $this->_setup_view(
			$view,
			$section,
			array_merge($this->_get_cat_sub_counts($section, $list_criteria), $this->_get_meta_variables($section->state, $view->jobs))
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
		$view->set_css('job_list.css');
		$view->set_include('job_location_list', 'job_location_list_v2.php');
		$view->set_include('content', 'job_location_list_page.php');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
		$view->display();
	}
	
	/**
	 * List states cities that have jobs.
	 */
	public function list_job_category_state_bachelor_action() {
		$db = $this->_general_env->get_db();
		$lang = $this->_global_environment->get_general_language();
		$domain = $this->_global_environment->get_domain();
		$opt_man = new Options_manager($db);
		$cache = $this->_global_environment->get_cache_storage();

		$level = new Education_level($db, Education_level::BACHELOR);

		$section = $this->_setup_site_section();
		$section->education_level = $level;

		$view = $this->_create_view($section->state->get_country(), true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'job_location_list_v2.php',
			date_create('tomorrow')->format('U') - date('U'),
			'state_category_cities_bachelor_'.$section->state->get_id().'_'.$section->job_category->get_id(),
			'loc_lists'
		);

		if (!$view->is_include_cached('job_location_list_v2.php')) {
			$searcher = City::get_searcher(new Db_searcher($db));
			$searcher->set_state_search($section->state);
			$cities = $searcher->search();
			
			$formatter = new Job_city_list_formatter(
				Static_job_list_searcher::init_mergable_searcher(
					Job::get_searcher(new Db_searcher($db)), $domain, [$section->job_category, $level, $lang]
				),
				new Latest_job_manager($db, $cache),
				$this->_get_container()->get_registered('SDB'),
				[$section->job_category, $level, $lang]
			);
			$params = [
				'state_abbr' => strtolower($section->state->get_abbr()),
				'city_id' => '<city_id>',
				'city_url_name' => '<city_url_name>',
				'job_category_url_name' => $_GET['job_category_url_name']];
			$url_template = $this->_url_manager->get_url('job_list', 'display_category_city_bachelor', $params);
			$view->locations = $formatter->format(
				$cities, $url_template, ['job_count', 'last_job_titles'], Job_location_list_formatter::ORDER_JOB_COUNT
			);
			if (!$view->locations) {
				$this->_redirect($this->_url_manager->get_url('job_list', 'display_category_state_bachelor', [
					'job_category_url_name' => $_GET['job_category_url_name'],
					'state_short_name' => $section->state->get_url_name(true),
					'state_id' => $section->state->get_id()
				]));
				return;
			}
			$view->number_of_columns = 1;
		}

		$formatter_builder = new Job_list_formatter_builder($this->_global_environment, $this->_url_manager, $cache);
		$list_formatter = $formatter_builder->build_job_list_formatter();
		$list_formatter->set_location_format('{short_state}(- - {city} -)');
		$location = new Location([$section->state]);
		$list_criteria = [$location, $section->job_category, $level, $lang];
		$short_job_list = new Short_job_list(
			Sphinx_job_list_searcher::get_fresh($db, $domain, $list_criteria),
			new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_STATE)
		);

		$view->jobs = $short_job_list->get_formatted_jobs($lang, 0, 2, $this->_get_ip_country(), $unformatted_jobs);
		$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(), Formatted_job_list::LOCATION_LEVEL_STATE);
		Top_job_table::assign_formatted_jobs(
			$this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), [$location, $section->job_category, $level, $lang]
		);
		
		$backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_MAIN, 'city_list', 'list_job_category_state_bachelor', $lang);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$meta_variables = $this->_get_meta_variables($section->state, $view->jobs);
		$meta_variables['{category}'] = $section->job_category->get_name($lang);
		$view = $this->_setup_view(
			$view,
			$section,
			array_merge($this->_get_cat_sub_counts($section, $list_criteria), $meta_variables)
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
		$view->set_css('job_list.css');
		$view->set_include('job_location_list', 'job_location_list_v2.php');
		$view->set_include('content', 'job_location_list_page.php');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
		$view->display();
	}

	/**
	 * List states cities that have jobs.
	 */
	public function list_job_subcategory_state_bachelor_action() {
		$db = $this->_general_env->get_db();
		$lang = $this->_global_environment->get_general_language();
		$cache = $this->_global_environment->get_cache_storage();
		$domain = $this->_global_environment->get_domain();
		$opt_man = new Options_manager($db);

		$level = new Education_level($db, Education_level::BACHELOR);

		$section = $this->_setup_site_section();
		$section->education_level = $level;

		$view = $this->_create_view($section->state->get_country(), true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'job_location_list_v2.php',
			date_create('tomorrow')->format('U') - date('U'),
			'state_subcategory_cities_bachelor'.$section->state->get_id().'_'.$section->job_subcategory->get_id(),
			'loc_lists'
		);

		if (!$view->is_include_cached('job_location_list_v2.php')) {
			$city_list_searcher = new Job_city_list_searcher(
				$domain,
				City::get_searcher(new Db_searcher($db)),
				Job::get_searcher(new Db_searcher($db)),
				[$section->state, $section->job_subcategory]
			);

			$cities = $city_list_searcher->find_cities();
			
			$formatter = new Job_city_list_formatter(
				Static_job_list_searcher::init_mergable_searcher(
					Job::get_searcher(new Db_searcher($db)), $domain, [$section->job_subcategory, $level, $lang]
				),
				new Latest_job_manager($db, $cache),
				$this->_get_container()->get_registered('SDB'),
				[$section->job_subcategory, $level, $lang]
			);
			$url_template = $this->_url_manager->get_url('job_list', 'display_subcategory_city_bachelor', [
				'state_abbr' => strtolower($section->state->get_abbr()),
				'city_id' => '<city_id>',
				'city_url_name' => '<city_url_name>',
				'job_subcategory_url_name' => $section->job_subcategory->get_url_name($lang)
			]);
			$view->locations = $formatter->format(
				$cities, $url_template, ['job_count', 'last_job_titles'], Job_location_list_formatter::ORDER_JOB_COUNT
			);
			if (!$view->locations) {
				$this->_redirect($this->_url_manager->get_url('job_list', 'display_subcategory_state_bachelor', [
					'job_subcategory_url_name' => $section->job_subcategory->get_url_name($lang),
					'state_short_name' => $section->state->get_url_name(true),
					'state_id' => $section->state->get_id()
				]));
				return;
			}
			$view->number_of_columns = 1;
		}

		$formatter_builder = new Job_list_formatter_builder($this->_global_environment, $this->_url_manager, $cache);
		$list_formatter = $formatter_builder->build_job_list_formatter();
		$list_formatter->set_location_format('{short_state}(- - {city} -)');
		$list_formatter->set_short_empl_desc_length($opt_man->get_option('short_empl_desc_length'));
		$location = new Location([$section->state]);
		$list_criteria = [$location, $section->job_subcategory, $level, $lang];
		$short_job_list = new Short_job_list(
			Sphinx_job_list_searcher::get_fresh($db, $domain, $list_criteria),
			new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_STATE, true)
		);

		$view->jobs = $short_job_list->get_formatted_jobs($lang, 0, 2, $this->_get_ip_country(), $unformatted_jobs);
		$formatted_job_list = new Formatted_job_list($formatter_builder->build_job_list_formatter(), Formatted_job_list::LOCATION_LEVEL_STATE);
		Top_job_table::assign_formatted_jobs(
			$this->_global_environment, $view, $formatted_job_list, $this->_get_ip_country(), [$location, $section->job_subcategory, $level, $lang]
		);
		
		$backfill_options = new Backfill_options($db, Backfill_job_list2::TYPE_MAIN, 'city_list', 'list_job_subcategory_state_bachelor', $lang);
		$this->_setup_backfill($view, $unformatted_jobs, $section, $backfill_options);

		$meta_variables = $this->_get_meta_variables($section->state, $view->jobs);
		$meta_variables['{category}'] = $section->job_category->get_name($lang);
		$meta_variables['{subcategory}'] = $section->job_subcategory->get_name($lang);
		$view = $this->_setup_view(
			$view,
			$section,
			array_merge($this->_get_cat_sub_counts($section, $list_criteria), $meta_variables)
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
		$view->set_css('job_list.css');
		$view->set_include('job_location_list', 'job_location_list_v2.php');
		$view->set_include('content', 'job_location_list_page.php');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
		$view->display();
	}
}
