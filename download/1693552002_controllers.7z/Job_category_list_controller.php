<?php
/**
 * Controller for displaying a job category list.
 * @package controllers
 */
class Job_category_list_controller extends General_controller {
	const META_TOP_CITIES_COUNT = 3;
	
	const INIT_CACHE_SECONDS = 86400;
	
	/**
	 * Create page criteria models from GET parameters and assign them to a site section.
	 * @return Site_section
	 * @throws Page_not_found_exception If current URL parameters are invalid.
	 */
	private function _setup_site_section() {
		$section_builder = new Site_section_builder(
			$this->_general_env->get_db(), $this->_global_environment->get_general_language(), $this->_global_environment->get_cache_storage()
		);
		try {
			return $section_builder->build_site_section($_GET, $_SERVER['REQUEST_URI']);
		}
		catch (\InvalidArgumentException $e) {
			throw new \Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
	}
	
	/**
	 * Display a list of all job categories which have jobs.
	 */
    public function list_job_all_action() {
		$lang = $this->_global_environment->get_general_language();

		$view = $this->_create_view(null, true, null);
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'all_job_category_list.php', date_create('tomorrow')->format('U') - date('U'), 'job_all_'.$lang->get_id()
		);
		
		$category_link_template = $this->_url_manager->get_url(
					'country_list', 'list_job_all_category', array('job_category_url_name' => '<job_category_url_name>')
		);
		$this->_assign_category_and_job_lists($view, [$lang], $category_link_template, false);

		$section = $this->_setup_site_section();
		$view = $this->_setup_view($view, $section, $this->_get_cat_sub_counts($section, [$lang]));
		
		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->display();
	}
	
	/**
	 * Assign a category list and optional top and short job lists to the view.
	 * Categories are sorted by name.
	 * Sets the following view variables: categories, jobs, jobs_heading, top_jobs, top_jobs_heading
	 * Caching of all_job_category_list.php include must be enabled on the view before calling this method.
	 * @param General_view $view
	 * @param array $criteria
	 * @param string $category_link_template
	 * @param bool $with_jobs_lists 
	 * @param int|null $page_type_id page type id if certain categories can be disabled for that page type
	 */
	private function _assign_category_and_job_lists(General_view $view, array $criteria, $category_link_template, $with_jobs_lists, $page_type_id = null) {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$domain = $this->_global_environment->get_domain();
		$criteria[] = $lang;
		
		if (!$view->is_include_cached('all_job_category_list.php')) {
			$job_searcher = Static_job_list_searcher::init_mergable_searcher(Job::get_searcher(new Db_searcher($db)), $domain, $criteria);
			$category_searcher = Job_category::get_searcher(new Db_searcher($db));
			$category_searcher->set_job_searcher($job_searcher);
			if ($page_type_id) {
				$manager = new Enabled_page_manager($db);
				$manager->init_criteria_searcher($category_searcher, $page_type_id, 'Job_category');
			}
			$all_categories = $category_searcher->search();
			$formatted_categories = array();
			foreach ($all_categories as $job_category) {
				$category_link = str_replace('<job_category_url_name>', $job_category->get_url_name($lang), $category_link_template);
				$formatted_categories[] = array('name' => $job_category->get_name($lang), 'link' => $category_link);
				unset($category_link);
			}

			asort($formatted_categories);
			$view->categories = $formatted_categories;
			if (!$view->categories) {
				throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
			}
		}

		if ($with_jobs_lists) {
			$formatter_builder = new Job_list_formatter_builder(
				$this->_global_environment, $this->_url_manager, $this->_global_environment->get_cache_storage()
			);
			$list_formatter = $formatter_builder->build_job_list_formatter();
			$short_job_list = new Short_job_list(
				Sphinx_job_list_searcher::get_fresh($db, $domain, $criteria),
				new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_COUNTRY)
			);

			$view->jobs = $short_job_list->get_formatted_jobs($lang, 1, 2, $this->_get_ip_country());
			$view->jobs_heading = $lang->get_text('LATEST_JOBS_HEADING');
			Top_job_table::assign_formatted_jobs(
				$this->_global_environment, $view,
				new Formatted_job_list($list_formatter, Formatted_job_list::LOCATION_LEVEL_COUNTRY),
				$this->_get_ip_country(),
				$criteria
			);
		}
		
		$view->set_include('all_job_category_list', 'all_job_category_list.php');
		$view->set_include('content', 'job_list.php');
		$view->set_css('job_list.css');
		$view->set_include('job_list', 'job_list.php');
		$view->set_include('jobs', 'jobs.php');
	}

	/**
	 * This should list all categories of jobs in specific state.
	 */
	public function list_job_all_state_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$default_lang = App_language::get_default_general_language($db);
		if ($lang->get_id() != $default_lang->get_id()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		
		$section = $this->_setup_site_section();
		
		if ($section->country->get_id() != Country::USA) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$view = $this->_create_view($section->country, true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'all_job_category_list.php',
			date_create('tomorrow')->format('U') - date('U'),
			'job_all_state_'.$lang->get_id().'_'.$section->state->get_id()
		);
		
		$category_link_template = $this->_url_manager->get_url('job_list', 'display_category_state', array(
				'job_category_url_name' => '<job_category_url_name>',
				'state_id' => $section->state->get_id(),
				'state_short_name' => $section->state->get_url_name(true)
			));
		$this->_assign_category_and_job_lists($view, [$section->state, $lang], $category_link_template, true);
		
		$view = $this->_setup_view(
			$view,
			$section,
			array_merge(
				$this->_get_cat_sub_counts($section, [$section->state, $lang]),
				$this->_get_state_category_list_meta_vars($section->state, $view->jobs)
			)
		);
		
		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->display();
	}

	/**
	 * This should list all categories of jobs in specific coutnry.(Should support only usa as requested)
	 */
	public function list_job_all_country_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$default_lang = App_language::get_default_general_language($db);
		if ($lang->get_id() != $default_lang->get_id()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		
		$section = $this->_setup_site_section();

		if ($section->country->get_id() != Country::USA) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$view = $this->_create_view($section->country, true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'all_job_category_list.php',
			date_create('tomorrow')->format('U') - date('U'),
			'job_all_country_'.$lang->get_id().'_'.$section->country->get_id()
		);
		
		$category_link_template = $this->_url_manager->get_url('state_list', 'list_job_category_country', array(
				'job_category_url_name' => '<job_category_url_name>',
				'country_url_name' => $section->country->get_url_name($lang)
			));
		$this->_assign_category_and_job_lists($view, [$section->country, $lang], $category_link_template, true);
		
		$view = $this->_setup_view($view, $section, array_merge(
			['{last_job_titles}' => Meta_handler::get_last_job_titles($view->jobs)],
			$this->_get_cat_sub_counts($section, [$section->country, $lang])
		));

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->display();
	}
	
	/**
	 * This should list all categories of jobs in specific region.
	 */
	public function list_job_all_region_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$default_lang = App_language::get_default_general_language($db);
		if ($lang->get_id() != $default_lang->get_id()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}
		
		$section = $this->_setup_site_section();

		$view = $this->_create_view(null, true, null, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'all_job_category_list.php',
			date_create('tomorrow')->format('U') - date('U'),
			'job_all_region_'.$lang->get_id().'_'.$section->region->get_id()
		);
		
		$category_link_template = $this->_url_manager->get_url('job_list', 'display_category_region_page', array(
			'job_category_url_name' => '<job_category_url_name>', 'region_url_name' => $section->region->get_url_name($lang), 'page_number' => 1
		));
		$this->_assign_category_and_job_lists($view, [$section->region, $lang], $category_link_template, true);

		$view = $this->_setup_view(
			$view,
			$section,
			array_merge(
				['{last_job_titles}' => Meta_handler::get_last_job_titles($view->jobs)],
				$this->_get_cat_sub_counts($section, [$section->region, $lang])
			), 
			'',
			[],
			['region_url_name' => $_GET['region_url_name']]
		);
		
		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->display();
	}

	/**
	 * Display a list of all job categories which have CVs.
	 */
    public function list_cv_all_action() {
		$lang = $this->_global_environment->get_general_language();

		$view = $this->_create_view(null, true, null, new Afs_display_manager($this->_get_geoip_country()));
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'all_job_category_list.php', date_create('tomorrow')->format('U') - date('U'), 'cv_all_'.$lang->get_id()
		);

		if (!$view->is_include_cached('all_job_category_list.php')) {
			$all_categories = $this->_get_all_categories();
			$categories_with_cvs = array();
			foreach ($all_categories as $job_category) {
				//check if there are cvs in this category
				$cv_searcher = Cv::get_searcher(new Db_searcher($this->_general_env->get_db()));
				$cv_searcher->set_is_suspended_search(false);
				$cv_searcher->set_domain_search($this->_global_environment->get_domain());
				$cv_searcher->set_job_category_search($job_category);
				$cv_searcher->set_posting_language_search($lang);
				$found_cvs = $cv_searcher->search(1, 1);
				if (!empty($found_cvs)) {
					$category_link = $this->_url_manager->get_url(
						'country_list',
						'list_cv_all_category',
						array('job_category_url_name' => $job_category->get_url_name($lang))
					);
					$categories_with_cvs[] = array('name' => $job_category->get_name($lang), 'link' => $category_link);
				}
			}

			asort($categories_with_cvs);
			$view->categories = $categories_with_cvs;
		}

		$view->set_include('content', 'all_job_category_list.php');

		$current_page = $this->_get_current_site_page();
		if (!is_null($current_page)) {
			$view = $this->_set_site_page_meta($view, $current_page, array('{last_cv_titles}' => $this->_get_last_cvs_titles()));
		}
		$view->display();
	}
	
	/**
	 * @return string
	 */
	private function _get_last_cvs_titles() {
		$cv_list_searcher = new Static_cv_list_searcher(
			Cv::get_searcher(new Db_searcher($this->_general_env->get_db())),
			$this->_global_environment->get_domain(),
			$this->_global_environment->get_general_language(),
			array()
		);
		
		$num_cv_titles = 5;
		$cvs = $cv_list_searcher->find_cvs(1, $num_cv_titles);
		$cv_titles = array();
		foreach ($cvs as $cv) {
			$cv->init(array('title'));
			$cv_titles[] = $cv->get_title();
		}
		return implode(', ', $cv_titles);
	}

	/**
	 * @param State $current_state
	 * @param array $formatted_jobs
	 * @return array
	 */
	private function _get_state_category_list_meta_vars(State $current_state, array $formatted_jobs = array()) {
		$db = $this->_general_env->get_db();
		$top_city_list = new Top_job_city_list(
			$current_state,
			$db,
			$this->_global_environment->get_general_language(),
			$this->_get_container()->get_registered('SDB')
		);
		$top_cities = $top_city_list->get_formatted_cities($this->_url_manager, self::META_TOP_CITIES_COUNT, true);
		
		return array('{state}' => $current_state->get_short_name(), '{state_abbr}' => $current_state->get_abbr(),
			'{city1}' => $top_cities[0]['name'], '{city2}' => $top_cities[1]['name'], '{city3}' => $top_cities[2]['name'],
			'{last_job_titles}' => Meta_handler::get_last_job_titles($formatted_jobs));
	}

	/**
	 * @return array
	 */
	private function _get_all_categories() {
		$category_searcher = Job_category::get_searcher(new Db_searcher($this->_general_env->get_db()));
		$category_searcher->set_domain_search($this->_global_environment->get_domain());
		$all_categories = $category_searcher->search();
		return $all_categories;
	}

	/**
	 * This should list all categories of bachelor jobs
	 */
	public function list_job_bachelor_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$default_lang = App_language::get_default_general_language($db);
		if ($lang->get_id() != $default_lang->get_id()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$section = $this->_get_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		$view = $this->_create_view(null, true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'all_job_category_list.php', date_create('tomorrow')->format('U') - date('U'), 'job_all_bachelor_'.$lang->get_id()
		);
		
		$category_link_template = $this->_url_manager->get_url(
			'country_list', 'list_job_category_bachelor', ['job_category_url_name' => '<job_category_url_name>']
		);
		$this->_assign_category_and_job_lists(
			$view, [$section->education_level, $lang], $category_link_template, true, Enabled_page_manager::BACHELOR_PAGES
		);
		
		$view = $this->_setup_view(
			$view,
			$section,
			array_merge(
				['{last_job_titles}' => Meta_handler::get_last_job_titles($view->jobs)],
				$this->_get_cat_sub_counts($section, [$section->education_level, $lang])
			)
		);
		
		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->display();
	}

	/**
	 * This should list categories of bachelor jobs in a country
	 */
	public function list_job_country_bachelor_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$default_lang = App_language::get_default_general_language($db);
		if ($lang->get_id() != $default_lang->get_id()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		if ($section->country->get_id() != Country::USA) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$view = $this->_create_view(null, true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'all_job_category_list.php',
			date_create('tomorrow')->format('U') - date('U'),
			'job_country_bachelor_'.$lang->get_id().'_'.$section->country->get_id()
		);
		
		$category_link_template = $this->_url_manager->get_url('state_list', 'list_job_category_country_bachelor', array(
			'job_category_url_name' => '<job_category_url_name>',
			'country_short_name' => $section->country->get_url_name($lang, true)
		));
		$list_criteria = [$section->education_level, $section->country, $lang];
		$this->_assign_category_and_job_lists(
			$view, $list_criteria, $category_link_template, true, Enabled_page_manager::BACHELOR_PAGES
		);

		$view = $this->_setup_view(
			$view,
			$section,
			array_merge(['{last_job_titles}' => Meta_handler::get_last_job_titles($view->jobs)], $this->_get_cat_sub_counts($section, $list_criteria))
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->display();
	}

	/**
	 * This should list categories of bachelor jobs in a state
	 */
	public function list_job_state_bachelor_action() {
		$lang = $this->_global_environment->get_general_language();
		$db = $this->_general_env->get_db();
		$default_lang = App_language::get_default_general_language($db);

		if ($lang->get_id() != $default_lang->get_id()) {
			throw new Page_not_found_exception($_SERVER['REQUEST_URI']);
		}

		$section = $this->_setup_site_section();
		$section->education_level = new Education_level($db, Education_level::BACHELOR);
		$view = $this->_create_view(null, true, $section, new Afs_display_manager($this->_get_geoip_country()));
		$this->_assign_share_buttons($view);
		$view->enable_include_caching(//cache till midnight, since date change and jobs expire thus some locations/categories might become invalid
			'all_job_category_list.php', date_create('tomorrow')->format('U') - date('U'), 'job_state_bachelor_'.$lang->get_id()
		);
		
		$category_link_template = $this->_url_manager->get_url('job_list', 'display_category_state_bachelor', array(
			'job_category_url_name' => '<job_category_url_name>',
			'state_id' => $section->state->get_id(),
			'state_short_name' => $section->state->get_url_name(true)
		));
		$list_criteria = [$section->education_level, $section->state, $lang];
		$this->_assign_category_and_job_lists(
			$view, $list_criteria, $category_link_template, true, Enabled_page_manager::BACHELOR_PAGES
		);

		$view = $this->_setup_view(
			$view,
			$section,
			array_merge($this->_get_state_category_list_meta_vars($section->state, $view->jobs), $this->_get_cat_sub_counts($section, $list_criteria))
		);

		//we do not use same variable name as in job list controller as we include job_list.php and it would draw this link again, in a wrong place
		$view->search_jobs_link = $this->_url_manager->get_url('job_list', 'display_search_form');

		$view->display();
	}
}
